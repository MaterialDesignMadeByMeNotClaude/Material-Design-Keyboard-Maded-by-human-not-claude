package com.vibe.keyboard

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color

data class KbTheme(
    val name: String, val bg: Int, val key: Int, val fn: Int,
    val text: Int, val accent: Int, val onAccent: Int, val press: Int
)

fun prefs(ctx: Context): SharedPreferences = ctx.getSharedPreferences("vibe", Context.MODE_PRIVATE)

object Themes {
    private fun t(n: String, bg: String, k: String, f: String, tx: String, a: String, oa: String, p: String) =
        KbTheme(n, Color.parseColor(bg), Color.parseColor(k), Color.parseColor(f),
            Color.parseColor(tx), Color.parseColor(a), Color.parseColor(oa), Color.parseColor(p))

    val presets = listOf(
        t("Vibe Dark", "#1B1A22", "#34313F", "#262330", "#EDE7F6", "#CFBCFF", "#381E72", "#6F6A80"),
        t("Light", "#ECEFF1", "#FFFFFF", "#CFD8DC", "#212121", "#1976D2", "#FFFFFF", "#90A4AE"),
        t("AMOLED", "#000000", "#1A1A1A", "#0D0D0D", "#FFFFFF", "#00E676", "#000000", "#444444"),
        t("Lavender", "#EDE7F6", "#FFFFFF", "#D1C4E9", "#311B92", "#673AB7", "#FFFFFF", "#9575CD"),
        t("Forest", "#E8F5E9", "#FFFFFF", "#C8E6C9", "#1B5E20", "#2E7D32", "#FFFFFF", "#81C784"),
        t("Sunset", "#2B1B17", "#4E342E", "#3E2723", "#FFE0B2", "#FF9800", "#261300", "#8D6E63")
    )

    fun fromSeed(seed: Int, dark: Boolean): KbTheme {
        val hsv = FloatArray(3)
        Color.colorToHSV(seed, hsv)
        val h = hsv[0]
        fun c(s: Float, v: Float) = Color.HSVToColor(floatArrayOf(h, s, v))
        return if (dark)
            KbTheme("Custom", c(.18f, .11f), c(.16f, .24f), c(.20f, .17f), c(.10f, .95f), c(.45f, .98f), c(.90f, .20f), c(.30f, .55f))
        else
            KbTheme("Custom", c(.10f, .96f), c(.04f, 1f), c(.16f, .88f), c(.30f, .15f), c(.85f, .65f), Color.WHITE, c(.35f, .75f))
    }

    fun current(ctx: Context): KbTheme {
        val p = prefs(ctx)
        return if (p.getBoolean("custom", false))
            fromSeed(p.getInt("seed", Color.parseColor("#6750A4")), p.getBoolean("dark", true))
        else presets[p.getInt("theme", 0).coerceIn(0, presets.size - 1)]
    }
}

object Layouts {
    val langs = listOf("EN", "ES", "RU")
    val names = mapOf("EN" to "English", "ES" to "Español", "RU" to "Русский")

    fun letters(l: String): List<String> = when (l) {
        "ES" -> listOf("qwertyuiop", "asdfghjklñ", "zxcvbnm")
        "RU" -> listOf("йцукенгшщзхъ", "фывапролджэё", "ячсмитьбю")
        else -> listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
    }

    val symbols = listOf("@#\$%&-+()/", "~=_<>[]{}|", "*\"':;!?")
}

// Pixel-art pets: b=body(accent) d=detail e=eyes p=pink
object Mascots {
    val names = listOf("Off", "Cat", "Ghost", "Slime", "Robot")
    val art: List<List<String>> = listOf(
        emptyList(),
        listOf("bb......bb", "bbb....bbb", "bbbbbbbbbb", "bbebbbbebb", "bbbbbbbbbb", "bbbbppbbbb", ".bbbbbbbb.", "..bbbbbb.."),
        listOf("..bbbbbb..", ".bbbbbbbb.", "bbbbbbbbbb", "bbebbbbebb", "bbbbbbbbbb", "bbbbddbbbb", "bbbbbbbbbb", "b.bb.bb.bb"),
        listOf("...bbbb...", "..bbbbbb..", ".bbbbbbbb.", ".bebbbbeb.", "bbbbbbbbbb", "bbbbppbbbb", "bbbbbbbbbb"),
        listOf("....dd....", "....bb....", ".bbbbbbbb.", ".bebbbbeb.", ".bbbbbbbb.", ".bbdddbbb.", ".bbbbbbbb.", "..bb..bb..")
    )
}
