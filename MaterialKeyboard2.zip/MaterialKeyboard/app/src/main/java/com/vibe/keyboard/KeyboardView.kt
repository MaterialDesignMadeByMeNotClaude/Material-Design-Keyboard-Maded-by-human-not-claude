package com.vibe.keyboard

import android.content.Context
import android.graphics.*
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import kotlin.math.*

class KeyboardView(ctx: Context, private val l: Listener) : View(ctx) {

    interface Listener {
        fun onText(t: String)
        fun onDelete()
        fun onEnter()
        fun onPaste()
        fun onSettings()
    }

    private companion object {
        const val CHAR = 0; const val SHIFT = 1; const val DEL = 2; const val SYM = 3
        const val LANG = 4; const val SPACE = 5; const val ENTER = 6; const val SPACER = 7
        const val MASCOT = 8; const val EMOJI = 9; const val CLIP = 10; const val GEAR = 11
        val EMOJIS = ("😀 😂 😊 😍 😎 🥳 😭 😡 👍 👎 🙏 ❤️ 🔥 ✨ 🎉 💯 " +
                "🤔 😴 🤯 😅 🙌 👀 💀 💜 🐱 🐶 🌈 ⭐ 🍕 ☕ 🎮 🚀").split(" ")
        val EGG = listOf("L", "L", "L", ",", ".")
    }

    private class Key(val label: String, val type: Int, val w: Float = 1f) {
        var x = 0f; var y = 0f; var wd = 0f; var h = 0f
        var down = 0f; var rippleT = 0L; var rx = 0f; var ry = 0f
    }

    private class Row(val keys: List<Key>, val stretch: Boolean, val hw: Float = 1f)

    private var theme = Themes.current(ctx)
    private var lang = "EN"
    private var mode = 0 // 0 letters, 1 symbols, 2 emoji
    private var shift = false
    private var caps = false
    private var lastShift = 0L
    private var mascot = 1
    private var radius = 12
    private var gapH = 6
    private var gapV = 6
    private var rows: List<Row> = emptyList()
    private var pressed: Key? = null
    private var popKey: Key? = null
    private var pop = 0f
    private var kick = 0L
    private var eggStart = 0L
    private var lastFrame = SystemClock.uptimeMillis()
    private val tokens = ArrayList<String>()

    private val density = resources.displayMetrics.density
    private val fontScale = resources.configuration.fontScale
    private fun dp(v: Float) = v * density
    private fun sp(v: Float) = v * density * fontScale

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x33000000 }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private val eggPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val rect = RectF()
    private val path = Path()
    private val cookie = Path()
    private val matrix = Matrix()
    private var eggShader: BitmapShader? = null
    private val eggBmp: Bitmap? by lazy {
        try { BitmapFactory.decodeResource(resources, R.drawable.easter) } catch (e: Throwable) { null }
    }
    private val handler = Handler(Looper.getMainLooper())
    private val repeater = object : Runnable {
        override fun run() {
            l.onDelete()
            handler.postDelayed(this, 50)
        }
    }

    init { reload() }

    fun reload() {
        val p = prefs(context)
        theme = Themes.current(context)
        lang = (p.getString("lang", "EN") ?: "EN").let { if (it in Layouts.langs) it else "EN" }
        mascot = p.getInt("mascot", 1).coerceIn(0, Mascots.art.size - 1)
        radius = p.getInt("radius", 12)
        gapH = p.getInt("gap", 6)
        gapV = p.getInt("rowgap", 6)
        mode = 0; shift = false; caps = false
        rebuild()
    }

    private fun chars(s: String) = s.map { Key(it.toString(), CHAR) }

    private fun rebuild() {
        val rs = ArrayList<Row>()
        rs.add(Row(listOf(
            Key("", MASCOT, 2.2f), Key("😊", EMOJI, 1.2f), Key("📋", CLIP, 1.2f),
            Key("⚙️", GEAR, 1.2f), Key("", SPACER, 4.2f)
        ), true, 0.85f))
        if (mode == 2) {
            EMOJIS.chunked(8).forEach { ch -> rs.add(Row(ch.map { Key(it, CHAR) }, true)) }
            rs.add(Row(listOf(Key("ABC", SYM, 1.5f), Key("", SPACE, 5f), Key("", DEL, 1.5f), Key("", ENTER, 1.5f)), true))
        } else {
            rs.add(Row(chars("1234567890"), true))
            if (mode == 0) {
                val lt = Layouts.letters(lang)
                rs.add(Row(chars(lt[0]), false))
                rs.add(Row(chars(lt[1]), false))
                rs.add(Row(listOf(Key("", SHIFT, 1.5f)) + chars(lt[2]) + Key("", DEL, 1.5f), false))
            } else {
                val s = Layouts.symbols
                rs.add(Row(chars(s[0]), false))
                rs.add(Row(chars(s[1]), false))
                rs.add(Row(listOf(Key("", SPACER, 1.5f)) + chars(s[2]) + Key("", DEL, 1.5f), false))
            }
            rs.add(Row(listOf(
                Key(if (mode == 0) "?123" else "ABC", SYM, 1.5f), Key(",", CHAR), Key("", LANG, 1.2f),
                Key("", SPACE, 4f), Key(".", CHAR), Key("", ENTER, 1.5f)
            ), true))
        }
        rows = rs
        layoutKeys()
        invalidate()
    }

    private fun layoutKeys() {
        if (width == 0 || height == 0) return
        val padX = dp(3f); val padT = dp(4f); val padB = dp(8f)
        val total = rows.fold(0f) { a, r -> a + r.hw }
        val unit = (height - padT - padB) / total
        val avail = width - 2 * padX
        val maxSum = rows.filter { !it.stretch }.maxOfOrNull { r -> r.keys.fold(0f) { a, k -> a + k.w } } ?: 1f
        var y = padT
        for (r in rows) {
            val sum = r.keys.fold(0f) { a, k -> a + k.w }
            val u = if (r.stretch) avail / sum else avail / maxSum
            var x = padX + (avail - sum * u) / 2
            val h = r.hw * unit
            for (k in r.keys) {
                k.x = x; k.y = y; k.wd = k.w * u; k.h = h
                x += k.wd
            }
            y += h
        }
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), (dp(46f) * 5.85f + dp(12f)).toInt())
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        layoutKeys()
    }

    private fun label(k: Key) = when (k.type) {
        CHAR -> if (shift || caps) k.label.uppercase() else k.label
        SHIFT -> "⇧"
        DEL -> "⌫"
        ENTER -> "↵"
        LANG -> lang
        SPACE -> Layouts.names[lang] ?: ""
        else -> k.label
    }

    override fun onDraw(c: Canvas) {
        val now = SystemClock.uptimeMillis()
        val dt = (now - lastFrame).coerceIn(1L, 50L).toFloat()
        lastFrame = now
        var anim = false
        c.drawColor(theme.bg)
        val kd = 1f - exp(-dt / 45f)

        for (r in rows) for (k in r.keys) {
            if (k.type == SPACER) continue
            if (k.type == MASCOT) { drawMascot(c, k, now); continue }

            val tgt = if (k === pressed) 1f else 0f
            k.down += (tgt - k.down) * kd
            if (abs(tgt - k.down) > 0.01f) anim = true

            val s = 1f - 0.1f * k.down
            val hx = (k.wd - dp(gapH.toFloat())) / 2 * s
            val hy = (k.h - dp(gapV.toFloat())) / 2 * s
            val cx = k.x + k.wd / 2
            val cy = k.y + k.h / 2
            rect.set(cx - hx, cy - hy, cx + hx, cy + hy)
            val rad = min(dp(radius.toFloat()), min(hx, hy))

            c.drawRoundRect(rect.left, rect.top + dp(1.2f), rect.right, rect.bottom + dp(1.2f), rad, rad, shadow)
            val onAccent = k.type == ENTER || (k.type == SHIFT && caps)
            fill.color = when {
                onAccent -> theme.accent
                k.type == SPACE || k.type == CHAR -> theme.key
                else -> theme.fn
            }
            c.drawRoundRect(rect, rad, rad, fill)
            if (k.down > 0.02f) {
                fill.color = theme.press
                fill.alpha = (130 * k.down).toInt()
                c.drawRoundRect(rect, rad, rad, fill)
                fill.alpha = 255
            }

            // Material ripple
            val rt = now - k.rippleT
            if (k.rippleT != 0L && rt < 380) {
                anim = true
                val p = rt / 380f
                path.reset()
                path.addRoundRect(rect, rad, rad, Path.Direction.CW)
                c.save()
                c.clipPath(path)
                fill.color = theme.accent
                fill.alpha = ((1f - p) * 90).toInt()
                c.drawCircle(k.rx, k.ry, p * k.wd * 0.9f + dp(6f), fill)
                fill.alpha = 255
                c.restore()
            }

            txt.color = when {
                onAccent -> theme.onAccent
                k.type == SHIFT && shift -> theme.accent
                else -> theme.text
            }
            val size = when (k.type) {
                CHAR, SHIFT, DEL, ENTER -> 22f
                EMOJI, CLIP, GEAR -> 17f
                else -> 14f
            }
            txt.textSize = sp(size) * (1f - 0.06f * k.down)
            val ty = rect.centerY() - (txt.fontMetrics.ascent + txt.fontMetrics.descent) / 2
            c.drawText(label(k), rect.centerX(), ty, txt)
        }

        if (drawPop(c, dt)) anim = true
        if (now - kick < 400) anim = true
        if (drawEgg(c, now)) anim = true

        if (anim) postInvalidateOnAnimation()
        else if (mascot != 0) postInvalidateDelayed(50)
    }

    private fun drawMascot(c: Canvas, k: Key, now: Long) {
        val art = Mascots.art[mascot]
        if (art.isEmpty()) return
        val nr = art.size
        val nc = art[0].length
        val cell = min(k.wd * 0.9f / nc, k.h * 0.92f / nr)
        val ox = k.x + dp(6f)
        val oy = k.y + (k.h - nr * cell) / 2
        val bob = sin(now / 450.0).toFloat() * dp(1.2f)
        val jt = (now - kick) / 360f
        val jump = if (jt in 0f..1f) -sin(jt * PI).toFloat() * dp(9f) else 0f
        val blink = now % 3800 < 140
        val pink = Color.parseColor("#FF8A80")
        for (r in 0 until nr) for (col in 0 until nc) {
            val ch = art[r][col]
            if (ch == '.') continue
            fill.color = when (ch) {
                'b' -> theme.accent
                'e' -> if (blink) theme.accent else theme.onAccent
                'd' -> theme.onAccent
                else -> pink
            }
            val left = ox + col * cell
            val top = oy + r * cell + bob + jump
            c.drawRect(left, top, left + cell + 0.5f, top + cell + 0.5f, fill)
        }
        fill.color = theme.accent
    }

    private fun drawPop(c: Canvas, dt: Float): Boolean {
        val pk = popKey ?: return false
        pop += ((if (pressed === pk) 1f else 0f) - pop) * (1f - exp(-dt / 55f))
        if (pressed !== pk && pop < 0.03f) { popKey = null; pop = 0f; return false }
        val rr = dp(30f) * pop
        val cx = (pk.x + pk.wd / 2).coerceIn(dp(32f), width - dp(32f))
        val cy = max(pk.y - dp(26f), dp(32f))
        val rot = (1f - pop) * 1.4f
        cookie.reset()
        for (i in 0..96) {
            val a = (2 * PI * i / 96).toFloat()
            val r = rr * (1f + 0.075f * cos(7f * (a + rot)))
            val x = cx + r * cos(a)
            val y = cy + r * sin(a)
            if (i == 0) cookie.moveTo(x, y) else cookie.lineTo(x, y)
        }
        cookie.close()
        fill.color = theme.accent
        c.drawPath(cookie, fill)
        txt.color = theme.onAccent
        txt.textSize = sp(28f) * max(pop, 0.2f)
        c.drawText(label(pk), cx, cy - (txt.fontMetrics.ascent + txt.fontMetrics.descent) / 2, txt)
        return true
    }

    private fun drawEgg(c: Canvas, now: Long): Boolean {
        if (eggStart == 0L) return false
        val t = now - eggStart
        val bmp = eggBmp
        if (t > 3300 || bmp == null) { eggStart = 0L; return false }
        val p = min(1f, t / 450f)
        val q = p - 1f
        val sc = 1f + 2.70158f * q * q * q + 1.70158f * q * q
        val fade = if (t > 2900) 1f - (t - 2900) / 400f else 1f
        fill.color = Color.BLACK
        fill.alpha = (170 * fade).toInt()
        c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), fill)
        val d = min(width, height) * 0.62f * sc
        val cx = width / 2f
        val cy = height / 2f - dp(8f)
        fill.color = theme.accent
        fill.alpha = (255 * fade).toInt()
        c.drawCircle(cx, cy, d / 2 + dp(4f), fill)
        fill.alpha = 255
        val sh = eggShader ?: BitmapShader(bmp, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP).also { eggShader = it }
        matrix.setScale(d / bmp.width, d / bmp.height)
        matrix.postTranslate(cx - d / 2, cy - d / 2)
        sh.setLocalMatrix(matrix)
        eggPaint.shader = sh
        eggPaint.alpha = (255 * fade).toInt()
        c.drawCircle(cx, cy, d / 2, eggPaint)
        txt.color = Color.WHITE
        txt.alpha = (255 * fade).toInt()
        txt.textSize = sp(15f)
        c.drawText("made with vibes ✨", cx, cy + d / 2 + dp(24f), txt)
        return true
    }

    private fun find(x: Float, y: Float): Key? {
        val row = rows.firstOrNull { y < it.keys[0].y + it.keys[0].h } ?: rows.lastOrNull() ?: return null
        return row.keys.firstOrNull { it.type != SPACER && x >= it.x && x < it.x + it.wd }
    }

    private fun track(tok: String) {
        tokens.add(tok)
        if (tokens.size > EGG.size) tokens.removeAt(0)
        if (tokens == EGG) { tokens.clear(); eggStart = SystemClock.uptimeMillis() }
    }

    private fun commit(k: Key) {
        when (k.type) {
            CHAR -> { l.onText(label(k)); if (shift && !caps) shift = false }
            SHIFT -> {
                val now = SystemClock.uptimeMillis()
                if (caps) { caps = false; shift = false }
                else if (shift && now - lastShift < 350) caps = true
                else shift = !shift
                lastShift = now
            }
            SYM -> { mode = if (mode == 0) 1 else 0; rebuild() }
            EMOJI -> { mode = 2; rebuild() }
            LANG -> {
                val i = Layouts.langs.indexOf(lang)
                lang = Layouts.langs[(i + 1) % Layouts.langs.size]
                prefs(context).edit().putString("lang", lang).apply()
                mode = 0; shift = false; caps = false
                rebuild()
            }
            SPACE -> l.onText(" ")
            ENTER -> l.onEnter()
            CLIP -> l.onPaste()
            GEAR -> l.onSettings()
            MASCOT -> kick = SystemClock.uptimeMillis()
        }
        track(when (k.type) { CHAR -> k.label.lowercase(); LANG -> "L"; else -> "x" })
        invalidate()
    }

    private fun setPressed(k: Key?, x: Float, y: Float) {
        pressed = k
        if (k != null) {
            k.rippleT = SystemClock.uptimeMillis(); k.rx = x; k.ry = y
            if (k.type == CHAR) popKey = k
        }
        invalidate()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (eggStart != 0L) { eggStart = 0L; invalidate(); return true }
                val k = find(e.x, e.y)
                setPressed(k, e.x, e.y)
                if (k != null) {
                    performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    if (k.type == DEL) {
                        l.onDelete()
                        handler.postDelayed(repeater, 400)
                    }
                }
            }
            MotionEvent.ACTION_MOVE -> {
                val k = find(e.x, e.y)
                if (k !== pressed) {
                    handler.removeCallbacks(repeater)
                    setPressed(k, e.x, e.y)
                }
            }
            MotionEvent.ACTION_UP -> {
                handler.removeCallbacks(repeater)
                val k = pressed
                pressed = null
                if (k != null && k.type != DEL) commit(k) else invalidate()
            }
            MotionEvent.ACTION_CANCEL -> {
                handler.removeCallbacks(repeater)
                pressed = null
                invalidate()
            }
        }
        return true
    }

    override fun onDetachedFromWindow() {
        handler.removeCallbacks(repeater)
        super.onDetachedFromWindow()
    }
}
