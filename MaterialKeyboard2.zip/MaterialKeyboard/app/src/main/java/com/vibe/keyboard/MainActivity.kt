package com.vibe.keyboard

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val ink = Color.parseColor("#1C1B1F")
    private val purple = Color.parseColor("#6750A4")
    private val palette = listOf(
        "#6750A4", "#8E4EC6", "#AE2A8C", "#D1305E", "#E5484D", "#F76B15",
        "#FFA000", "#E5B813", "#8DC63F", "#30A46C", "#12A594", "#0BA5C4",
        "#0090FF", "#3E63DD", "#5B5BD6", "#795548", "#607D8B", "#1C1C24"
    )
    private lateinit var preview: KeyboardView
    private lateinit var input: EditText
    private lateinit var body: LinearLayout
    private var hexField: EditText? = null
    private var taps = 0

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun lp() = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#F4F3F7"))
        }
        input = EditText(this).apply {
            hint = "Test the keyboard here…"
            showSoftInputOnFocus = false
            setPadding(dp(16), dp(10), dp(16), dp(10))
        }
        preview = KeyboardView(this, object : KeyboardView.Listener {
            override fun onText(t: String) { input.append(t) }
            override fun onDelete() {
                val s = input.text
                if (s.isNotEmpty()) s.delete(s.length - 1, s.length)
            }
            override fun onEnter() { input.append("\n") }
            override fun onPaste() {}
            override fun onSettings() {}
        })
        body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(40), dp(16), dp(16))
        }
        root.addView(ScrollView(this).apply { addView(body) }, LinearLayout.LayoutParams(MATCH, 0, 1f))
        root.addView(input, LinearLayout.LayoutParams(MATCH, WRAP))
        root.addView(preview, LinearLayout.LayoutParams(MATCH, WRAP))
        setContentView(root)
        render()
    }

    private fun pill(t: String, bg: Int, fg: Int, sel: Boolean = false, click: () -> Unit): TextView =
        TextView(this).apply {
            text = t
            setTextColor(fg)
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(24).toFloat()
                setColor(bg)
                if (sel) setStroke(dp(2), ink)
            }
            setOnClickListener { click() }
        }

    private fun dot(color: Int, sel: Boolean, click: () -> Unit): View = View(this).apply {
        background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
            if (sel) setStroke(dp(3), ink) else setStroke(dp(1), Color.parseColor("#33000000"))
        }
        layoutParams = LinearLayout.LayoutParams(dp(36), dp(36)).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }
        setOnClickListener { click() }
    }

    private fun card(title: String, vararg views: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(18), dp(16), dp(18), dp(16))
        background = GradientDrawable().apply { cornerRadius = dp(24).toFloat(); setColor(Color.WHITE) }
        layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(12) }
        addView(TextView(context).apply {
            text = title; textSize = 17f; setTextColor(ink); setPadding(0, 0, 0, dp(8))
        })
        views.forEach { addView(it) }
    }

    private fun seek(f: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) { f(v) }
        override fun onStartTrackingTouch(s: SeekBar?) {}
        override fun onStopTrackingTouch(s: SeekBar?) {}
    }

    private fun slider(label: String, key: String, def: Int, maxV: Int): View {
        val p = prefs(this)
        val cur = p.getInt(key, def)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val tv = TextView(this).apply { text = "$label · $cur dp"; setTextColor(ink) }
        val sb = SeekBar(this).apply { max = maxV; progress = cur }
        sb.setOnSeekBarChangeListener(seek { v ->
            tv.text = "$label · $v dp"
            p.edit().putInt(key, v).apply()
            preview.reload()
        })
        col.addView(tv)
        col.addView(sb)
        return col
    }

    private fun saveSeed(c: Int) {
        prefs(this).edit().putBoolean("custom", true).putInt("seed", c).apply()
    }

    private fun render() {
        val p = prefs(this)
        body.removeAllViews()

        body.addView(TextView(this).apply {
            text = "Vibe Keyboard"; textSize = 32f; setTextColor(ink)
            setOnClickListener { if (++taps >= 7) { taps = 0; showEgg() } }
        })
        body.addView(TextView(this).apply {
            text = "English · Español · Русский"; setTextColor(Color.parseColor("#625B71")); setPadding(0, 0, 0, dp(8))
        })
        body.addView(pill("1 · Enable keyboard", purple, Color.WHITE) {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }, lp())
        body.addView(pill("2 · Choose keyboard", purple, Color.WHITE) {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        }, lp())

        // Themes
        val custom = p.getBoolean("custom", false)
        val sel = p.getInt("theme", 0)
        val dots = LinearLayout(this)
        Themes.presets.forEachIndexed { i, th ->
            dots.addView(dot(th.accent, !custom && i == sel) {
                p.edit().putBoolean("custom", false).putInt("theme", i).apply()
                render()
            })
        }
        val themeName = if (custom) "Custom color" else Themes.presets[sel.coerceIn(0, Themes.presets.size - 1)].name
        body.addView(card("Theme · $themeName", dots))

        // Custom color
        val seed = p.getInt("seed", purple)
        val hsv = FloatArray(3)
        Color.colorToHSV(seed, hsv)
        val hex = EditText(this).apply {
            setText(String.format("#%06X", 0xFFFFFF and seed))
            setSingleLine()
            setTextColor(ink)
        }
        hexField = hex
        val applyHex = pill("Apply HEX", Color.parseColor("#E8DEF8"), ink) {
            try {
                var s = hex.text.toString().trim()
                if (!s.startsWith("#")) s = "#$s"
                saveSeed(Color.parseColor(s))
                render()
            } catch (e: Exception) {
                Toast.makeText(this, "Invalid HEX color", Toast.LENGTH_SHORT).show()
            }
        }
        val hue = SeekBar(this).apply { max = 359; progress = hsv[0].toInt().coerceIn(0, 359) }
        hue.setOnSeekBarChangeListener(seek { v ->
            val c = Color.HSVToColor(floatArrayOf(v.toFloat(), 0.8f, 0.85f))
            saveSeed(c)
            hexField?.setText(String.format("#%06X", 0xFFFFFF and c))
            preview.reload()
        })
        val dark = Switch(this).apply {
            text = "Dark keyboard"
            isChecked = p.getBoolean("dark", true)
            setOnCheckedChangeListener { _, b -> p.edit().putBoolean("dark", b).apply(); preview.reload() }
        }
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        palette.chunked(6).forEach { rowColors ->
            val r = LinearLayout(this)
            rowColors.forEach { hx ->
                val c = Color.parseColor(hx)
                r.addView(dot(c, custom && c == seed) { saveSeed(c); render() })
            }
            grid.addView(r)
        }
        body.addView(card("Custom color", grid, hue, hex, applyHex, dark))

        // Keys
        body.addView(card("Keys",
            slider("Key rounding", "radius", 12, 24),
            slider("Key spacing", "gap", 6, 12),
            slider("Row spacing", "rowgap", 6, 14)))

        // Mascot
        val mCur = p.getInt("mascot", 1)
        val chips = LinearLayout(this)
        Mascots.names.forEachIndexed { i, n ->
            chips.addView(
                pill(n, if (i == mCur) Color.parseColor("#E8DEF8") else Color.parseColor("#F4F3F7"), ink, i == mCur) {
                    p.edit().putInt("mascot", i).apply(); render()
                },
                LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginEnd = dp(4) })
        }
        body.addView(card("Mascot", chips))

        preview.reload()
    }

    private fun showEgg() {
        val img = ImageView(this).apply {
            setImageResource(R.drawable.easter)
            adjustViewBounds = true
            setPadding(dp(24), dp(16), dp(24), dp(8))
        }
        AlertDialog.Builder(this).setTitle("✨ You found it!").setView(img).setPositiveButton("Nice", null).show()
    }
}
