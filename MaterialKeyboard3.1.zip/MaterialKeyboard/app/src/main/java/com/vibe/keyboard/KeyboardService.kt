package com.vibe.keyboard

import android.content.ClipboardManager
import android.content.Intent
import android.inputmethodservice.InputMethodService
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Toast

class KeyboardService : InputMethodService(), KeyboardView.Listener {
    private var view: KeyboardView? = null
    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener { ClipStore.addCurrent(this) }

    override fun onCreate() {
        super.onCreate()
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).addPrimaryClipChangedListener(clipListener)
        Tr.preload(this, true) { }
    }

    override fun onDestroy() {
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).removePrimaryClipChangedListener(clipListener)
        super.onDestroy()
    }

    override fun onCreateInputView(): View {
        val v = KeyboardView(this, this)
        view = v
        return v
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        ClipStore.addCurrent(this)
        view?.reload()
    }

    override fun onText(t: String) { currentInputConnection?.commitText(t, 1) }

    override fun onDelete() { sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL) }

    override fun onEnter() {
        val opts = currentInputEditorInfo?.imeOptions ?: 0
        val action = opts and EditorInfo.IME_MASK_ACTION
        val noAction = (opts and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (noAction || action == EditorInfo.IME_ACTION_NONE || action == EditorInfo.IME_ACTION_UNSPECIFIED) {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        } else {
            currentInputConnection?.performEditorAction(action)
        }
    }

    override fun onSettings() {
        startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    override fun textBefore(n: Int): String = currentInputConnection?.getTextBeforeCursor(n, 0)?.toString() ?: ""

    override fun replace(len: Int, s: String) {
        val ic = currentInputConnection ?: return
        ic.beginBatchEdit()
        ic.deleteSurroundingText(len, 0)
        ic.commitText(s, 1)
        ic.endBatchEdit()
    }

    override fun onVoice() {
        VoiceBridge.onResult = { text ->
            VoiceBridge.onResult = null
            view?.setListening(false)
            if (!text.isNullOrEmpty()) currentInputConnection?.commitText("$text ", 1)
        }
        val lang = prefs(this).getString("lang", "EN") ?: "EN"
        startActivity(
            Intent(this, VoiceActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
                .putExtra("lang", Layouts.tags[lang] ?: "en-US")
        )
    }

    override fun onTranslate() {
        val ic = currentInputConnection ?: return
        val sel = ic.getSelectedText(0)?.toString()
        val hasSel = !sel.isNullOrEmpty()
        val before = if (hasSel) "" else ic.getTextBeforeCursor(3000, 0)?.toString() ?: ""
        val after = if (hasSel) "" else ic.getTextAfterCursor(3000, 0)?.toString() ?: ""
        val text = if (hasSel) sel!! else before + after
        if (text.isBlank()) {
            Toast.makeText(this, "Type something to translate", Toast.LENGTH_SHORT).show()
            return
        }
        val src = prefs(this).getString("lang", "EN") ?: "EN"
        view?.setBusy(true)
        Tr.run(src, Tr.target(this, src), text, { out ->
            view?.setBusy(false)
            val c = currentInputConnection
            if (!hasSel) c?.deleteSurroundingText(before.length, after.length)
            c?.commitText(out, 1)
        }, {
            view?.setBusy(false)
            Toast.makeText(this, "Translation failed. Internet is needed once to download the language pack.", Toast.LENGTH_LONG).show()
        })
    }
}
