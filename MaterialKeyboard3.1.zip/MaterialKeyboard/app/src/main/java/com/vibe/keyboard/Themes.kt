package com.vibe.keyboard

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint

data class KbTheme(
    val name: String, val bg: Int, val key: Int, val fn: Int,
    val text: Int, val accent: Int, val onAccent: Int, val press: Int,
    val fx: String = "", val bg2: Int = 0, val border: Int = 0,
    val glass: Boolean = false, val mono: Boolean = false
)

fun prefs(ctx: Context): SharedPreferences = ctx.getSharedPreferences("vibe", Context.MODE_PRIVATE)

fun mixColor(a: Int, b: Int, t: Float): Int {
    val k = t.coerceIn(0f, 1f)
    return Color.argb(
        (Color.alpha(a) + (Color.alpha(b) - Color.alpha(a)) * k).toInt(),
        (Color.red(a) + (Color.red(b) - Color.red(a)) * k).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * k).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * k).toInt()
    )
}

fun shadeColor(c: Int, f: Float) = Color.argb(
    Color.alpha(c), (Color.red(c) * f).toInt().coerceIn(0, 255),
    (Color.green(c) * f).toInt().coerceIn(0, 255), (Color.blue(c) * f).toInt().coerceIn(0, 255)
)

object Themes {
    private fun pc(h: String) = Color.parseColor(h)
    private fun t(n: String, bg: String, k: String, f: String, tx: String, a: String, oa: String, p: String,
                  fx: String = "", bg2: String? = null, border: String? = null, glass: Boolean = false, mono: Boolean = false) =
        KbTheme(n, pc(bg), pc(k), pc(f), pc(tx), pc(a), pc(oa), pc(p), fx, bg2?.let { pc(it) } ?: 0, border?.let { pc(it) } ?: 0, glass, mono)

    val presets = listOf(
        t("Vibe Dark", "#1B1A22", "#34313F", "#262330", "#EDE7F6", "#CFBCFF", "#381E72", "#6F6A80"),
        t("Light", "#ECEFF1", "#FFFFFF", "#CFD8DC", "#212121", "#1976D2", "#FFFFFF", "#90A4AE"),
        t("AMOLED", "#000000", "#1A1A1A", "#0D0D0D", "#FFFFFF", "#00E676", "#000000", "#444444"),
        t("Lavender", "#EDE7F6", "#FFFFFF", "#D1C4E9", "#311B92", "#673AB7", "#FFFFFF", "#9575CD"),
        t("Forest", "#E8F5E9", "#FFFFFF", "#C8E6C9", "#1B5E20", "#2E7D32", "#FFFFFF", "#81C784", fx = "rain"),
        t("Sunset", "#2B1B17", "#4E342E", "#3E2723", "#FFE0B2", "#FF9800", "#261300", "#8D6E63", fx = "leaves"),
        t("Winter", "#0D1B2E", "#1D3552", "#142A44", "#E8F4FF", "#8FD3FF", "#06304D", "#4A7BA8", fx = "snow"),
        t("Frost", "#E3F2FD", "#FFFFFF", "#BBDEFB", "#0D2B45", "#2196F3", "#FFFFFF", "#64B5F6", fx = "snow"),
        t("Liquid Glass", "#3A4FD7", "#38FFFFFF", "#24FFFFFF", "#FFFFFF", "#FFFFFF", "#2B2A8F", "#66FFFFFF",
            bg2 = "#C25CD9", border = "#80FFFFFF", glass = true),
        t("Terminal", "#050A06", "#0E1A10", "#09120B", "#3DFF73", "#3DFF73", "#02200C", "#1D5C32",
            border = "#1C6B35", mono = true),
        t("Chocolate", "#22110A", "#4A2B1B", "#341D12", "#F7E4D2", "#E9B67E", "#3A1D0B", "#7C5538", border = "#5E3B27")
    )

    fun fromSeed(seed: Int, dark: Boolean): KbTheme {
        val hsv = FloatArray(3)
        Color.colorToHSV(seed, hsv)
        val h = hsv[0]
        fun c(s: Float, v: Float) = Color.HSVToColor(floatArrayOf(h, s, v))
        return if (dark)
            KbTheme("Custom", c(.18f, .11f), c(.16f, .24f), c(.20f, .17f), c(.10f, .95f), c(.45f, .98f), c(.90f, .20f), c(.30f, .55f))
        else
            KbTheme("Custom", c(.10f, .96f), c(.04f, 1f), c(.16f, .88f), c(.30f, .15f), c(.85f, .65f), Color.WHITE, c(.35f, .75f))
    }

    fun current(ctx: Context): KbTheme {
        val p = prefs(ctx)
        return if (p.getBoolean("custom", false))
            fromSeed(p.getInt("seed", Color.parseColor("#6750A4")), p.getBoolean("dark", true))
        else presets[p.getInt("theme", 0).coerceIn(0, presets.size - 1)]
    }

    /** Weather effect in use: pref "weather" = auto (follow theme) | none | snow | rain | leaves */
    fun fx(ctx: Context, th: KbTheme): String = when (val w = prefs(ctx).getString("weather", "auto") ?: "auto") {
        "auto" -> th.fx
        "none" -> ""
        else -> w
    }
}

object Layouts {
    val langs = listOf("EN", "ES", "RU", "PT")
    val names = mapOf("EN" to "English", "ES" to "Español", "RU" to "Русский", "PT" to "Português")
    val tags = mapOf("EN" to "en-US", "ES" to "es-ES", "RU" to "ru-RU", "PT" to "pt-BR")

    fun letters(l: String): List<String> = when (l) {
        "ES" -> listOf("qwertyuiop", "asdfghjklñ", "zxcvbnm")
        "RU" -> listOf("йцукенгшщзхъ", "фывапролджэё", "ячсмитьбю")
        "PT" -> listOf("qwertyuiop", "asdfghjklç", "zxcvbnm")
        else -> listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
    }

    val symbols = listOf("1234567890", "@#\$%&-+()/", "*\"':;!?")
    val symbols2 = listOf("~=_<>[]{}|", "€£¥₽©®™§°", "\\^`•÷×±")
}

/** Long-press alternatives (accents, digits on the top row, punctuation). */
object Alts {
    private val en = mapOf("a" to "àáâäæãåā", "c" to "çćč", "e" to "èéêëēėę", "i" to "îïíīįì", "l" to "ł",
        "n" to "ñń", "o" to "ôöòóœøōõ", "s" to "ßśš", "u" to "ûüùúū", "y" to "ÿý", "z" to "žźż")
    private val es = mapOf("a" to "áàâäãå", "e" to "éèêë", "i" to "íìîï", "o" to "óòôöõ", "u" to "úùûü", "n" to "ñ", "c" to "ç")
    private val pt = mapOf("a" to "áàâãä", "c" to "ç", "e" to "éêè", "i" to "íî", "o" to "óôõ", "u" to "úü")
    private val ru = mapOf("е" to "ё", "ь" to "ъ")
    private val sym = mapOf("-" to "–—•", "'" to "‘’‹›", "\"" to "“”«»", "?" to "¿", "!" to "¡", "\$" to "€£¥¢₽",
        "%" to "‰", "(" to "[{<", ")" to "]}>", "/" to "\\", "+" to "±", "=" to "≠≈", "*" to "†‡★", "<" to "«≤",
        ">" to "»≥", "&" to "§", "#" to "№", "@" to "©®™", "~" to "≈", "_" to "‾")

    fun of(lang: String, ch: String, mode: Int, dig: String): List<String> {
        val acc = if (mode == 0) when (ch) {
            "." -> if (lang == "ES") "¿¡…?!:;" else "…?!:;"
            "," -> "'\"-;"
            else -> (when (lang) { "ES" -> es; "PT" -> pt; "RU" -> ru; else -> en })[ch] ?: ""
        } else sym[ch] ?: ""
        return (dig + acc).map { it.toString() }
    }
}

/**
 * Pixel pets, 12 columns wide.
 * o outline · b body · l highlight · s shade · e eye · h eye shine · g visor glow · k dark · p blush · w white
 */
object Mascots {
    val names = listOf("Off", "Cat", "Ghost", "Slime", "Robot", "Alien")
    val art: List<List<String>> = listOf(
        emptyList(),
        listOf( // Cat
            ".oo......oo.", "obbo....obbo", "obbbooooobbo", "obbbbbbbbbbo", "obbehbbehbbo",
            "obbbbbkbbbbo", "obpbbwwwbpbo", ".obbbbbbbbo.", "..oooooooo.."
        ),
        listOf( // Ghost
            "...oooooo...", "..obbbbbbo..", ".oblbbbbbbo.", "obbbbbbbbbbo", "obbehbbehbbo",
            "obbbbbbbbbbo", "obpbbkkbbpbo", "obbbbbbbbbbo", "obbbbbbbbbbo", "obbobbbbobbo", ".oo.oooo.oo."
        ),
        listOf( // Slime
            "....oooo....", "..ooblbbo...", ".obbbbbbbbo.", ".obehbbehbbo", "obbbbbbbbbbo",
            "obpbbkkbbpbo", "obbbbbbbbbbo", ".oooooooooo."
        ),
        listOf( // Robot
            ".....kk.....", ".....oo.....", "..oooooooo..", ".obbbbbbbbo.", "obkkkkkkkkbo",
            "obkggkkggkbo", "obkkkkkkkkbo", ".obbbbbbbbo.", "..obbddbbo..", "..obbbbbbo..", "..oo....oo.."
        ),
        listOf( // Alien
            "...oooooo...", "..obbbbbbo..", ".obbbbbbbbo.", "obbehbbehbbo", "obbbbbbbbbbo",
            "obbbbkkbbbbo", ".obbbbbbbbo.", ".obobobobobo", ".o.o.o.o.o.o"
        )
    )

    fun drawArt(c: Canvas, p: Paint, idx: Int, left: Float, top: Float, cell: Float, accent: Int, blink: Boolean) {
        val a = art.getOrNull(idx) ?: return
        val outline = shadeColor(accent, 0.38f)
        val hi = mixColor(accent, Color.WHITE, 0.5f)
        val sh = shadeColor(accent, 0.72f)
        val dark = Color.parseColor("#1A1420")
        for (r in a.indices) for (col in a[r].indices) {
            val ch = a[r][col]
            val color = when (ch) {
                '.' -> continue
                'o' -> outline
                'b' -> accent
                'l' -> hi
                's', 'd' -> sh
                'e' -> if (blink) outline else dark
                'h' -> if (blink) outline else Color.WHITE
                'g' -> if (blink) dark else Color.parseColor("#B8F5FF")
                'k' -> dark
                'p' -> Color.parseColor("#FF8FA3")
                'w' -> Color.WHITE
                else -> accent
            }
            p.color = color
            val x = left + col * cell; val y = top + r * cell
            c.drawRect(x, y, x + cell + 0.6f, y + cell + 0.6f, p)
        }
    }
}
