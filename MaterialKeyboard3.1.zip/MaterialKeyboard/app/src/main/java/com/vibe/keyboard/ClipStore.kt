package com.vibe.keyboard

import android.content.ClipboardManager
import android.content.Context
import org.json.JSONArray

/** Small clipboard history (last 20 copies), kept on-device. */
object ClipStore {
    private const val KEY = "clips"

    fun enabled(ctx: Context) = prefs(ctx).getBoolean("cliphist", true)

    fun items(ctx: Context): List<String> {
        val s = prefs(ctx).getString(KEY, null) ?: return emptyList()
        return try {
            val a = JSONArray(s)
            (0 until a.length()).map { a.getString(it) }
        } catch (e: Exception) { emptyList() }
    }

    private fun save(ctx: Context, l: List<String>) {
        prefs(ctx).edit().putString(KEY, JSONArray(l).toString()).apply()
    }

    fun add(ctx: Context, text: String) {
        if (!enabled(ctx)) return
        val t = text.trim().take(500)
        if (t.isEmpty()) return
        val l = items(ctx).toMutableList()
        l.remove(t)
        l.add(0, t)
        while (l.size > 20) l.removeAt(l.size - 1)
        save(ctx, l)
    }

    fun clear(ctx: Context) { prefs(ctx).edit().remove(KEY).apply() }

    /** Reads the current system clip (skipping anything marked sensitive, like passwords). */
    fun addCurrent(ctx: Context) {
        try {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = cm.primaryClip ?: return
            if (clip.itemCount == 0) return
            if (clip.description?.extras?.getBoolean("android.content.extra.IS_SENSITIVE", false) == true) return
            add(ctx, clip.getItemAt(0).coerceToText(ctx)?.toString() ?: return)
        } catch (e: Exception) { }
    }
}
