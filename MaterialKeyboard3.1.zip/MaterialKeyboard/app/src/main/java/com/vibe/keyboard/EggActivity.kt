package com.vibe.keyboard

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.animation.OvershootInterpolator
import android.widget.ImageView

class EggActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        val img = ImageView(this).apply {
            setImageResource(R.drawable.easter2)
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.BLACK)
            setOnClickListener { finish() }
            alpha = 0f; scaleX = 0.9f; scaleY = 0.9f
        }
        setContentView(img)
        img.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(450).setInterpolator(OvershootInterpolator(1.2f)).start()
    }
}
