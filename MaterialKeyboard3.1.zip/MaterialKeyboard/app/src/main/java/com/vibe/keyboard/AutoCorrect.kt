package com.vibe.keyboard

import android.content.Context
import kotlin.math.abs
import kotlin.math.min

/** Offline autocorrect: frequency-ordered dictionaries in assets/dict_xx.txt + words the user teaches it. */
object AutoCorrect {
    class Result(val slots: Array<String?>, val auto: String?)

    private class Dict(val words: List<String>) {
        val rank = HashMap<String, Int>(words.size * 2).also { m -> words.forEachIndexed { i, w -> m.putIfAbsent(w, i) } }
    }

    private val dicts = HashMap<String, Dict>()
    private var learned: MutableSet<String>? = null
    private var a0 = IntArray(48); private var a1 = IntArray(48); private var a2 = IntArray(48)

    @Synchronized
    private fun dict(ctx: Context, lang: String): Dict = dicts.getOrPut(lang) {
        val words = try {
            ctx.applicationContext.assets.open("dict_${lang.lowercase()}.txt").bufferedReader().readLines()
        } catch (e: Exception) { emptyList() }
        Dict(words)
    }

    fun warm(ctx: Context, lang: String) { Thread { dict(ctx, lang) }.start() }

    private fun learnedSet(ctx: Context): MutableSet<String> =
        learned ?: HashSet<String>(prefs(ctx).getStringSet("learned", null) ?: emptySet()).also { learned = it }

    fun learn(ctx: Context, w: String) {
        val s = learnedSet(ctx)
        if (s.add(w.lowercase())) prefs(ctx).edit().putStringSet("learned", HashSet(s)).apply()
    }

    fun clearLearned(ctx: Context) {
        learned = HashSet()
        prefs(ctx).edit().remove("learned").apply()
    }

    fun learnedCount(ctx: Context) = learnedSet(ctx).size

    fun cased(orig: String, s: String): String = when {
        orig.length > 1 && orig.all { it.isUpperCase() } -> s.uppercase()
        orig.isNotEmpty() && orig[0].isUpperCase() -> s.replaceFirstChar { it.uppercase() }
        else -> s
    }

    /** slots = [left, center, right]; auto = what would replace the typed word on space/punctuation. */
    fun suggest(ctx: Context, lang: String, typed: String): Result {
        val d = dict(ctx, lang)
        val low = typed.lowercase()
        val n = low.length
        val known = d.rank.containsKey(low) || learnedSet(ctx).contains(low)

        val comps = ArrayList<String>(3)
        for (w in d.words) {
            if (w.length > n && w.startsWith(low)) { comps.add(w); if (comps.size >= 3) break }
        }

        val slots = arrayOfNulls<String>(3)
        if (known) {
            slots[1] = typed
            comps.getOrNull(0)?.let { slots[0] = cased(typed, it) }
            comps.getOrNull(1)?.let { slots[2] = cased(typed, it) }
            return Result(slots, null)
        }

        val maxD = if (n <= 2) 0 else if (n <= 5) 1 else 2
        val fixes = ArrayList<Long>()
        if (maxD > 0) {
            val a = low.toCharArray()
            for (i in d.words.indices) {
                val w = d.words[i]
                if (abs(w.length - n) > maxD || w.length > 40 || n > 40) continue
                val dist = osa(a, w, maxD)
                if (dist in 1..maxD) fixes.add(dist.toLong() * 1_000_000L + i)
            }
            fixes.sort()
        }
        if (fixes.isNotEmpty()) {
            val list = LinkedHashSet<String>()
            for (f in fixes) { list.add(d.words[(f % 1_000_000L).toInt()]); if (list.size >= 2) break }
            if (list.size < 2) comps.firstOrNull { it !in list }?.let { list.add(it) }
            val l = list.toList()
            slots[0] = typed
            slots[1] = cased(typed, l[0])
            slots[2] = l.getOrNull(1)?.let { cased(typed, it) }
            return Result(slots, slots[1])
        }
        slots[1] = typed
        comps.getOrNull(0)?.let { slots[0] = cased(typed, it) }
        comps.getOrNull(1)?.let { slots[2] = cased(typed, it) }
        return Result(slots, null)
    }

    /** Damerau-Levenshtein (optimal string alignment) with early exit. */
    private fun osa(a: CharArray, b: String, maxD: Int): Int {
        val n = a.size; val m = b.length
        var p2 = a0; var p1 = a1; var cur = a2
        for (j in 0..m) p1[j] = j
        for (i in 1..n) {
            cur[0] = i
            var rowMin = i
            for (j in 1..m) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                var v = min(min(p1[j] + 1, cur[j - 1] + 1), p1[j - 1] + cost)
                if (i > 1 && j > 1 && a[i - 1] == b[j - 2] && a[i - 2] == b[j - 1]) v = min(v, p2[j - 2] + 1)
                cur[j] = v
                if (v < rowMin) rowMin = v
            }
            if (rowMin > maxD) return maxD + 1
            val t = p2; p2 = p1; p1 = cur; cur = t
        }
        return p1[m]
    }
}
