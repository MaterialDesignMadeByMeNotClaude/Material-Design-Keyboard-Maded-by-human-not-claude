package com.vibe.keyboard

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin

/**
 * Hand-drawn vector icons on a 24x24 grid. Nothing here is an emoji or a font glyph.
 * t = click animation progress (0 = idle, 0..1 while playing), a / e = icon specific amounts.
 */
object Ic {
    const val SMILE = 0; const val CLIP = 1; const val TRANS = 2; const val GEAR = 3; const val GRID = 4
    const val CHEV = 5; const val MIC = 6; const val WAND = 7; const val SHIFT = 8; const val BACK = 9
    const val ENTER = 10; const val GLOBE = 11; const val SNOW = 12; const val PAW = 13; const val PALETTE = 14
    const val KEYS = 15; const val VIBRATE = 16; const val CHECK = 17
    const val LEAF = 18; const val RAIN = 19; const val TERM = 20; const val DOWN = 21; const val TRASH = 22
    const val HEART = 23; const val SLIDERS = 24; const val CLOCK = 25; const val INFO = 26

    private val path = Path()
    private val r = RectF()

    fun draw(c: Canvas, id: Int, cx: Float, cy: Float, s: Float, p: Paint, t: Float = 0f, a: Float = 0f, e: Float = 0f) {
        val oStyle = p.style; val oW = p.strokeWidth; val oCap = p.strokeCap; val oJoin = p.strokeJoin; val oAlpha = p.alpha
        c.save()
        c.translate(cx - s / 2, cy - s / 2)
        c.scale(s / 24f, s / 24f)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2f
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        val ease = if (t <= 0f) 0f else 1f - (1f - t.coerceAtMost(1f)).pow(3)
        val wob = if (t <= 0f) 0f else (sin(t * PI * 3) * (1f - t)).toFloat()

        when (id) {
            SMILE -> {
                c.rotate(wob * 14f, 12f, 12f)
                c.drawCircle(12f, 12f, 9f, p)
                p.style = Paint.Style.FILL
                c.drawCircle(9f, 10f, 1.25f, p); c.drawCircle(15f, 10f, 1.25f, p)
                p.style = Paint.Style.STROKE
                r.set(7.2f, 7.2f, 16.8f, 16.8f)
                c.drawArc(r, 28f, 124f, false, p)
            }
            CLIP -> {
                c.translate(0f, -abs(wob) * 2.5f)
                r.set(5f, 4.5f, 19f, 21.5f); c.drawRoundRect(r, 2.5f, 2.5f, p)
                p.style = Paint.Style.FILL
                r.set(9f, 2.5f, 15f, 6.5f); c.drawRoundRect(r, 1.6f, 1.6f, p)
                p.style = Paint.Style.STROKE
                c.drawLine(8.5f, 12f, 15.5f, 12f, p); c.drawLine(8.5f, 16f, 13f, 16f, p)
            }
            TRANS -> {
                val sx = cos(ease * 2 * PI).toFloat()
                c.scale(if (abs(sx) < 0.06f) 0.06f else sx, 1f, 12f, 12f)
                p.strokeWidth = 1.9f
                c.drawLine(3.5f, 6f, 13f, 6f, p); c.drawLine(8.2f, 3.5f, 8.2f, 6f, p)
                path.reset(); path.moveTo(11.5f, 6f); path.quadTo(10.5f, 11.5f, 4.5f, 14.5f); c.drawPath(path, p)
                path.reset(); path.moveTo(6f, 9f); path.quadTo(8.5f, 13.5f, 13f, 15f); c.drawPath(path, p)
                path.reset(); path.moveTo(12.5f, 21f); path.lineTo(16.5f, 10.5f); path.lineTo(20.5f, 21f); c.drawPath(path, p)
                c.drawLine(14f, 17.5f, 19f, 17.5f, p)
            }
            GEAR -> {
                c.rotate(ease * 90f, 12f, 12f)
                c.drawCircle(12f, 12f, 6.4f, p)
                p.strokeWidth = 3.2f
                for (i in 0 until 8) {
                    val an = i * PI / 4
                    val ca = cos(an).toFloat(); val sa = sin(an).toFloat()
                    c.drawLine(12f + ca * 7.9f, 12f + sa * 7.9f, 12f + ca * 9.4f, 12f + sa * 9.4f, p)
                }
                p.strokeWidth = 2f
                c.drawCircle(12f, 12f, 2.5f, p)
            }
            GRID -> {
                c.rotate(ease * 90f, 12f, 12f)
                p.style = Paint.Style.FILL
                for (gx in floatArrayOf(4f, 13.5f)) for (gy in floatArrayOf(4f, 13.5f)) {
                    r.set(gx, gy, gx + 6.5f, gy + 6.5f); c.drawRoundRect(r, 1.9f, 1.9f, p)
                }
            }
            CHEV -> {
                c.translate(0f, wob * 1.5f)
                p.strokeWidth = 2.4f
                path.reset(); path.moveTo(6f, 9f); path.lineTo(12f, 15f); path.lineTo(18f, 9f); c.drawPath(path, p)
            }
            MIC -> {
                val sc = 1f + abs(wob) * 0.12f
                c.scale(sc, sc, 12f, 12f)
                r.set(9f, 2.5f, 15f, 14f)
                p.style = if (a > 0.5f) Paint.Style.FILL_AND_STROKE else Paint.Style.STROKE
                c.drawRoundRect(r, 3f, 3f, p)
                p.style = Paint.Style.STROKE
                r.set(5.5f, 6.5f, 18.5f, 19f); c.drawArc(r, 0f, 180f, false, p)
                c.drawLine(12f, 19f, 12f, 21.5f, p); c.drawLine(8.5f, 21.5f, 15.5f, 21.5f, p)
            }
            WAND -> {
                c.rotate(wob * -18f, 12f, 12f)
                p.strokeWidth = 2.8f
                c.drawLine(4.5f, 19.5f, 14f, 10f, p)
                p.style = Paint.Style.FILL
                path.reset()
                path.moveTo(17.5f, 2f); path.quadTo(17.5f, 6.5f, 22f, 6.5f); path.quadTo(17.5f, 6.5f, 17.5f, 11f)
                path.quadTo(17.5f, 6.5f, 13f, 6.5f); path.quadTo(17.5f, 6.5f, 17.5f, 2f); path.close()
                c.drawPath(path, p)
                path.reset()
                path.moveTo(7f, 3.6f); path.quadTo(7f, 6f, 9.4f, 6f); path.quadTo(7f, 6f, 7f, 8.4f)
                path.quadTo(7f, 6f, 4.6f, 6f); path.quadTo(7f, 6f, 7f, 3.6f); path.close()
                c.drawPath(path, p)
            }
            SHIFT -> {
                path.reset()
                path.moveTo(12f, 3.5f); path.lineTo(20.5f, 12.5f); path.lineTo(16f, 12.5f); path.lineTo(16f, 19f)
                path.lineTo(8f, 19f); path.lineTo(8f, 12.5f); path.lineTo(3.5f, 12.5f); path.close()
                if (a > 0.01f) {
                    p.style = Paint.Style.FILL; p.alpha = (oAlpha * a.coerceIn(0f, 1f)).toInt()
                    c.drawPath(path, p)
                }
                p.style = Paint.Style.STROKE; p.alpha = oAlpha
                c.drawPath(path, p)
                if (e > 0.01f) {
                    p.alpha = (oAlpha * e.coerceIn(0f, 1f)).toInt(); p.strokeWidth = 2.4f
                    c.drawLine(8f, 22.2f, 16f, 22.2f, p)
                }
            }
            BACK -> {
                c.translate(-wob * 2f, 0f)
                path.reset()
                path.moveTo(8.5f, 5.5f); path.lineTo(19.5f, 5.5f); path.quadTo(21.5f, 5.5f, 21.5f, 7.5f)
                path.lineTo(21.5f, 16.5f); path.quadTo(21.5f, 18.5f, 19.5f, 18.5f); path.lineTo(8.5f, 18.5f)
                path.lineTo(2.5f, 12f); path.close()
                c.drawPath(path, p)
                p.strokeWidth = 1.8f
                c.drawLine(12.5f, 9.5f, 17.5f, 14.5f, p); c.drawLine(17.5f, 9.5f, 12.5f, 14.5f, p)
            }
            ENTER -> {
                c.translate(wob * -2f, 0f)
                path.reset(); path.moveTo(19f, 5f); path.lineTo(19f, 12f); path.lineTo(6f, 12f); c.drawPath(path, p)
                path.reset(); path.moveTo(10.5f, 7.5f); path.lineTo(6f, 12f); path.lineTo(10.5f, 16.5f); c.drawPath(path, p)
            }
            GLOBE -> {
                c.drawCircle(12f, 12f, 9f, p)
                val ew = 4f * abs(cos(ease * PI).toFloat()) + 0.3f
                r.set(12f - ew, 3f, 12f + ew, 21f); c.drawOval(r, p)
                p.strokeWidth = 1.7f
                c.drawLine(3f, 12f, 21f, 12f, p)
                c.drawLine(4.6f, 7.6f, 19.4f, 7.6f, p); c.drawLine(4.6f, 16.4f, 19.4f, 16.4f, p)
            }
            SNOW -> {
                c.rotate(ease * 60f, 12f, 12f)
                p.strokeWidth = 1.8f
                for (i in 0 until 6) {
                    c.save(); c.rotate(i * 60f, 12f, 12f)
                    c.drawLine(12f, 12f, 12f, 3f, p)
                    c.drawLine(12f, 6.4f, 9.8f, 4.3f, p); c.drawLine(12f, 6.4f, 14.2f, 4.3f, p)
                    c.restore()
                }
            }
            PAW -> {
                c.translate(0f, -abs(wob) * 2.5f)
                p.style = Paint.Style.FILL
                c.drawCircle(6.3f, 11f, 2.1f, p); c.drawCircle(9.9f, 6.6f, 2.1f, p)
                c.drawCircle(14.1f, 6.6f, 2.1f, p); c.drawCircle(17.7f, 11f, 2.1f, p)
                r.set(7f, 12.3f, 17f, 20.8f); c.drawOval(r, p)
            }
            PALETTE -> {
                c.rotate(wob * 20f, 12f, 12f)
                c.drawCircle(12f, 12f, 9f, p)
                p.style = Paint.Style.FILL
                c.drawCircle(8f, 10f, 1.5f, p); c.drawCircle(12f, 7.4f, 1.5f, p)
                c.drawCircle(16f, 10f, 1.5f, p); c.drawCircle(9f, 15.2f, 1.5f, p)
            }
            KEYS -> {
                r.set(2.5f, 6.5f, 21.5f, 17.5f); c.drawRoundRect(r, 3f, 3f, p)
                p.style = Paint.Style.FILL
                for (x in floatArrayOf(6.5f, 10.2f, 13.8f, 17.5f)) c.drawCircle(x, 10.3f, 1.05f, p)
                p.style = Paint.Style.STROKE; p.strokeWidth = 1.8f
                c.drawLine(7.5f, 14.2f, 16.5f, 14.2f, p)
            }
            VIBRATE -> {
                c.translate(wob * 1.6f, 0f)
                r.set(8f, 3.5f, 16f, 20.5f); c.drawRoundRect(r, 2f, 2f, p)
                c.drawLine(4.8f, 9f, 4.8f, 15f, p); c.drawLine(19.2f, 9f, 19.2f, 15f, p)
                c.drawLine(2.2f, 10.8f, 2.2f, 13.2f, p); c.drawLine(21.8f, 10.8f, 21.8f, 13.2f, p)
            }
            LEAF -> {
                c.rotate(wob * 25f, 12f, 12f)
                path.reset(); path.moveTo(5f, 19f); path.cubicTo(4f, 9f, 11f, 4f, 20f, 4f); path.cubicTo(20f, 12f, 15f, 19f, 5f, 19f); path.close()
                c.drawPath(path, p)
                c.drawLine(5f, 19f, 14f, 10f, p)
            }
            RAIN -> {
                path.reset(); path.moveTo(7f, 14f); path.cubicTo(3.5f, 14f, 3.5f, 8.5f, 7.5f, 8.5f); path.cubicTo(8.5f, 4.5f, 15.5f, 4.5f, 16.5f, 9f)
                path.cubicTo(20.5f, 9f, 20.5f, 14f, 17f, 14f); path.close()
                c.drawPath(path, p)
                val dy = ease * 1.8f
                c.drawLine(8f, 16.5f + dy, 7f, 19.5f + dy, p); c.drawLine(12.5f, 16.5f + dy, 11.5f, 19.5f + dy, p); c.drawLine(17f, 16.5f + dy, 16f, 19.5f + dy, p)
            }
            TERM -> {
                r.set(2.5f, 4.5f, 21.5f, 19.5f); c.drawRoundRect(r, 3f, 3f, p)
                path.reset(); path.moveTo(7f, 9.5f); path.lineTo(10.5f, 12f); path.lineTo(7f, 14.5f); c.drawPath(path, p)
                c.drawLine(12.5f, 15f, 17f, 15f, p)
            }
            DOWN -> {
                c.translate(0f, abs(wob) * 2f)
                c.drawLine(12f, 4f, 12f, 14.5f, p)
                path.reset(); path.moveTo(7.5f, 10f); path.lineTo(12f, 14.5f); path.lineTo(16.5f, 10f); c.drawPath(path, p)
                c.drawLine(5f, 19.5f, 19f, 19.5f, p)
            }
            TRASH -> {
                c.rotate(wob * 8f, 12f, 20f)
                c.drawLine(4f, 6.5f, 20f, 6.5f, p)
                path.reset(); path.moveTo(9f, 6.5f); path.lineTo(9f, 4.5f); path.lineTo(15f, 4.5f); path.lineTo(15f, 6.5f); c.drawPath(path, p)
                path.reset(); path.moveTo(6.5f, 6.5f); path.lineTo(7.5f, 20f); path.lineTo(16.5f, 20f); path.lineTo(17.5f, 6.5f); c.drawPath(path, p)
                c.drawLine(10f, 10f, 10f, 16f, p); c.drawLine(14f, 10f, 14f, 16f, p)
            }
            HEART -> {
                val sc = 1f + abs(wob) * 0.18f
                c.scale(sc, sc, 12f, 12f)
                path.reset(); path.moveTo(12f, 20f); path.cubicTo(5f, 15f, 3f, 11f, 3f, 8.5f); path.cubicTo(3f, 5.5f, 5.5f, 4f, 7.7f, 4f)
                path.cubicTo(9.5f, 4f, 11f, 5f, 12f, 6.5f); path.cubicTo(13f, 5f, 14.5f, 4f, 16.3f, 4f); path.cubicTo(18.5f, 4f, 21f, 5.5f, 21f, 8.5f)
                path.cubicTo(21f, 11f, 19f, 15f, 12f, 20f); path.close()
                c.drawPath(path, p)
            }
            SLIDERS -> {
                c.drawLine(4f, 7f, 20f, 7f, p); c.drawLine(4f, 12f, 20f, 12f, p); c.drawLine(4f, 17f, 20f, 17f, p)
                p.style = Paint.Style.FILL
                val s1 = ease * 3f
                c.drawCircle(9f + s1, 7f, 2.3f, p); c.drawCircle(15f - s1, 12f, 2.3f, p); c.drawCircle(8f + s1, 17f, 2.3f, p)
            }
            CLOCK -> {
                c.drawCircle(12f, 12f, 9f, p)
                c.rotate(ease * 360f, 12f, 12f)
                path.reset(); path.moveTo(12f, 7f); path.lineTo(12f, 12f); path.lineTo(15.5f, 14f); c.drawPath(path, p)
            }
            INFO -> {
                c.drawCircle(12f, 12f, 9f, p)
                c.drawLine(12f, 11f, 12f, 16.5f, p)
                p.style = Paint.Style.FILL; c.drawCircle(12f, 7.8f, 1.3f, p)
            }
            CHECK -> {
                p.strokeWidth = 2.6f
                path.reset(); path.moveTo(5f, 12.8f); path.lineTo(10f, 17.5f); path.lineTo(19f, 7f); c.drawPath(path, p)
            }
        }
        c.restore()
        p.style = oStyle; p.strokeWidth = oW; p.strokeCap = oCap; p.strokeJoin = oJoin; p.alpha = oAlpha
    }
}
