package com.example.materialkb

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun pill(t: String, bg: Int, fg: Int, stroke: Int, sw: Int, onClick: () -> Unit): TextView =
        TextView(this).apply {
            text = t
            setTextColor(fg)
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = GradientDrawable().apply {
                cornerRadius = dp(28).toFloat()
                setColor(bg)
                setStroke(sw, stroke)
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(10) }
            setOnClickListener { onClick() }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val blue = Color.parseColor("#1976D2")
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(48), dp(24), dp(24))
        }
        root.addView(TextView(this).apply {
            text = "Teclado Material"; textSize = 30f; setTextColor(Color.parseColor("#212121"))
        })
        root.addView(TextView(this).apply {
            text = "Español · English · Русский"; textSize = 15f
            setTextColor(Color.parseColor("#607D8B")); setPadding(0, dp(4), 0, dp(16))
        })
        root.addView(pill("1. Activar teclado", blue, Color.WHITE, blue, 0) {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        })
        root.addView(pill("2. Elegir teclado", blue, Color.WHITE, blue, 0) {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        })
        root.addView(TextView(this).apply {
            text = "Tema"; textSize = 18f; setTextColor(Color.parseColor("#212121"))
            setPadding(0, dp(24), 0, dp(4))
        })
        val sel = Themes.index(this)
        Themes.all.forEachIndexed { i, th ->
            val mark = if (i == sel) "✓  " else ""
            root.addView(pill(mark + th.name, th.key, th.text, th.accent, if (i == sel) dp(3) else dp(1)) {
                prefs(this).edit().putInt("theme", i).apply()
                recreate()
            })
        }
        root.addView(EditText(this).apply {
            hint = "Prueba el teclado aquí"
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(24) }
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }
}
