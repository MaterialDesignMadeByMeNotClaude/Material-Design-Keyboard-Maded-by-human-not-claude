package com.example.materialkb

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color

data class KbTheme(
    val name: String, val bg: Int, val key: Int, val fn: Int,
    val text: Int, val accent: Int, val onAccent: Int, val press: Int
)

fun prefs(ctx: Context): SharedPreferences = ctx.getSharedPreferences("kb", Context.MODE_PRIVATE)

object Themes {
    private fun t(n: String, bg: String, k: String, f: String, tx: String, a: String, oa: String, p: String) =
        KbTheme(n, Color.parseColor(bg), Color.parseColor(k), Color.parseColor(f),
            Color.parseColor(tx), Color.parseColor(a), Color.parseColor(oa), Color.parseColor(p))

    val all = listOf(
        t("Claro", "#ECEFF1", "#FFFFFF", "#CFD8DC", "#212121", "#1976D2", "#FFFFFF", "#90A4AE"),
        t("Oscuro", "#1F1F1F", "#3A3A3A", "#2C2C2C", "#EEEEEE", "#90CAF9", "#0D2B4A", "#6B6B6B"),
        t("AMOLED", "#000000", "#1A1A1A", "#0D0D0D", "#FFFFFF", "#00E676", "#000000", "#444444"),
        t("Lavanda", "#EDE7F6", "#FFFFFF", "#D1C4E9", "#311B92", "#673AB7", "#FFFFFF", "#9575CD"),
        t("Bosque", "#E8F5E9", "#FFFFFF", "#C8E6C9", "#1B5E20", "#2E7D32", "#FFFFFF", "#81C784"),
        t("Atardecer", "#2B1B17", "#4E342E", "#3E2723", "#FFE0B2", "#FF9800", "#261300", "#8D6E63")
    )

    fun index(ctx: Context) = prefs(ctx).getInt("theme", 0).coerceIn(0, all.size - 1)
    fun current(ctx: Context) = all[index(ctx)]
}

object Layouts {
    val langs = listOf("ES", "EN", "RU")
    val names = mapOf("ES" to "Español", "EN" to "English", "RU" to "Русский")

    fun letters(l: String): List<String> = when (l) {
        "ES" -> listOf("qwertyuiop", "asdfghjklñ", "zxcvbnm")
        "RU" -> listOf("йцукенгшщзхъ", "фывапролджэё", "ячсмитьбю")
        else -> listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
    }

    val symbols = listOf("@#\$%&-+()/", "~=_<>[]{}|", "*\"':;!?")
}
