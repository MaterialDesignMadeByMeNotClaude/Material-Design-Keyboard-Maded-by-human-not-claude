package com.example.materialkb

import android.content.Context
import android.graphics.*
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View

class KeyboardView(ctx: Context, private val l: Listener) : View(ctx) {

    interface Listener {
        fun onText(t: String)
        fun onDelete()
        fun onEnter()
    }

    private companion object {
        const val CHAR = 0; const val SHIFT = 1; const val DEL = 2; const val SYM = 3
        const val LANG = 4; const val SPACE = 5; const val ENTER = 6; const val SPACER = 7
    }

    private class Key(val label: String, val type: Int, val w: Float = 1f) {
        var x = 0f; var y = 0f; var wd = 0f; var h = 0f
    }

    private class Row(val keys: List<Key>, val stretch: Boolean)

    private var theme = Themes.current(ctx)
    private var lang = prefs(ctx).getString("lang", "ES") ?: "ES"
    private var sym = false
    private var shift = false
    private var caps = false
    private var lastShift = 0L
    private var rows: List<Row> = emptyList()
    private var pressed: Key? = null

    private val density = resources.displayMetrics.density
    private val fontScale = resources.configuration.fontScale
    private fun dp(v: Float) = v * density
    private fun sp(v: Float) = v * density * fontScale

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x33000000 }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private val rect = RectF()
    private val handler = Handler(Looper.getMainLooper())
    private val repeat = object : Runnable {
        override fun run() {
            l.onDelete()
            handler.postDelayed(this, 50)
        }
    }

    init { rebuild() }

    fun reload() {
        theme = Themes.current(context)
        lang = prefs(context).getString("lang", "ES") ?: "ES"
        sym = false; shift = false; caps = false
        rebuild()
    }

    private fun chars(s: String) = s.map { Key(it.toString(), CHAR) }

    private fun rebuild() {
        val top = Row(chars("1234567890"), true)
        val r1: Row; val r2: Row; val r3: Row
        if (!sym) {
            val lt = Layouts.letters(lang)
            r1 = Row(chars(lt[0]), false)
            r2 = Row(chars(lt[1]), false)
            r3 = Row(listOf(Key("", SHIFT, 1.5f)) + chars(lt[2]) + Key("", DEL, 1.5f), false)
        } else {
            val s = Layouts.symbols
            r1 = Row(chars(s[0]), false)
            r2 = Row(chars(s[1]), false)
            r3 = Row(listOf(Key("", SPACER, 1.5f)) + chars(s[2]) + Key("", DEL, 1.5f), false)
        }
        val bottom = Row(listOf(
            Key(if (sym) "ABC" else "?123", SYM, 1.5f), Key(",", CHAR), Key("", LANG, 1.2f),
            Key("", SPACE, 4f), Key(".", CHAR), Key("", ENTER, 1.5f)
        ), true)
        rows = listOf(top, r1, r2, r3, bottom)
        layoutKeys()
        invalidate()
    }

    private val padX get() = dp(3f)
    private val padT get() = dp(6f)
    private val padB get() = dp(8f)

    private fun layoutKeys() {
        if (width == 0 || height == 0) return
        val rh = (height - padT - padB) / rows.size
        val avail = width - 2 * padX
        val maxSum = rows.filter { !it.stretch }.maxOf { r -> r.keys.fold(0f) { a, k -> a + k.w } }
        rows.forEachIndexed { i, r ->
            val sum = r.keys.fold(0f) { a, k -> a + k.w }
            val unit = if (r.stretch) avail / sum else avail / maxSum
            var x = padX + (avail - sum * unit) / 2
            for (k in r.keys) {
                k.x = x; k.y = padT + i * rh; k.wd = k.w * unit; k.h = rh
                x += k.wd
            }
        }
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), (dp(50f) * 5 + padT + padB).toInt())
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        layoutKeys()
    }

    private fun label(k: Key) = when (k.type) {
        CHAR -> if (shift || caps) k.label.uppercase() else k.label
        SHIFT -> "⇧"
        DEL -> "⌫"
        ENTER -> "↵"
        LANG -> lang
        SPACE -> Layouts.names[lang] ?: ""
        else -> k.label
    }

    override fun onDraw(c: Canvas) {
        c.drawColor(theme.bg)
        val gap = dp(3f); val rad = dp(10f)
        for (r in rows) for (k in r.keys) {
            if (k.type == SPACER) continue
            rect.set(k.x + gap, k.y + gap, k.x + k.wd - gap, k.y + k.h - gap)
            c.drawRoundRect(rect.left, rect.top + dp(1.2f), rect.right, rect.bottom + dp(1.2f), rad, rad, shadow)
            val onAccent = k.type == ENTER || (k.type == SHIFT && caps)
            fill.color = when {
                onAccent -> theme.accent
                k.type == SPACE || k.type == CHAR -> theme.key
                else -> theme.fn
            }
            c.drawRoundRect(rect, rad, rad, fill)
            if (k === pressed) {
                fill.color = theme.press; fill.alpha = 170
                c.drawRoundRect(rect, rad, rad, fill); fill.alpha = 255
            }
            txt.color = when {
                onAccent -> theme.onAccent
                k.type == SHIFT && shift -> theme.accent
                else -> theme.text
            }
            val big = k.type == CHAR || k.type == SHIFT || k.type == DEL || k.type == ENTER
            txt.textSize = sp(if (big) 22f else 14f)
            val cy = rect.centerY() - (txt.fontMetrics.ascent + txt.fontMetrics.descent) / 2
            c.drawText(label(k), rect.centerX(), cy, txt)
        }
    }

    private fun find(x: Float, y: Float): Key? {
        val rh = (height - padT - padB) / rows.size
        val ri = ((y - padT) / rh).toInt().coerceIn(0, rows.size - 1)
        return rows[ri].keys.firstOrNull { it.type != SPACER && x >= it.x && x < it.x + it.wd }
    }

    private fun commit(k: Key) {
        when (k.type) {
            CHAR -> { l.onText(label(k)); if (shift && !caps) shift = false }
            SHIFT -> {
                val now = SystemClock.uptimeMillis()
                if (caps) { caps = false; shift = false }
                else if (shift && now - lastShift < 350) caps = true
                else shift = !shift
                lastShift = now
            }
            SYM -> { sym = !sym; rebuild() }
            LANG -> {
                val i = Layouts.langs.indexOf(lang)
                lang = Layouts.langs[(i + 1) % Layouts.langs.size]
                prefs(context).edit().putString("lang", lang).apply()
                sym = false; shift = false; caps = false
                rebuild()
            }
            SPACE -> l.onText(" ")
            ENTER -> l.onEnter()
        }
        invalidate()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val k = find(e.x, e.y)
                pressed = k
                if (k != null) {
                    performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    if (k.type == DEL) {
                        l.onDelete()
                        handler.postDelayed(repeat, 400)
                    }
                }
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                val k = find(e.x, e.y)
                if (k !== pressed) {
                    handler.removeCallbacks(repeat)
                    pressed = k
                    invalidate()
                }
            }
            MotionEvent.ACTION_UP -> {
                handler.removeCallbacks(repeat)
                val k = pressed
                pressed = null
                if (k != null && k.type != DEL) commit(k) else invalidate()
            }
            MotionEvent.ACTION_CANCEL -> {
                handler.removeCallbacks(repeat)
                pressed = null
                invalidate()
            }
        }
        return true
    }

    override fun onDetachedFromWindow() {
        handler.removeCallbacks(repeat)
        super.onDetachedFromWindow()
    }
}
