package com.vibe.keyboard

import android.content.Context
import android.graphics.*
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import kotlin.math.*
import kotlin.random.Random

class KeyboardView(ctx: Context, private val l: Listener) : View(ctx) {

    interface Listener {
        fun onText(t: String)
        fun onDelete()
        fun onEnter()
        fun onPaste()
        fun onSettings()
        fun onVoice()
        fun onTranslate()
        fun textBefore(n: Int): String
        fun replace(len: Int, s: String)
    }

    private companion object {
        const val CHAR = 0; const val SHIFT = 1; const val DEL = 2; const val SYM = 3
        const val LANG = 4; const val SPACE = 5; const val ENTER = 6; const val SPACER = 7
        const val WIDGETS = 8; const val MIC = 9; const val TOOL = 10; const val SUGG = 11; const val TILE = 12
        const val A_EMOJI = 1; const val A_CLIP = 2; const val A_TRANS = 3; const val A_AUTO = 4; const val A_GEAR = 5
        const val A_MASCOT = 6; const val A_THEME = 7; const val A_SNOW = 8; const val A_TLANG = 9; const val A_HAPTIC = 10
        const val TOP_HW = 1f
        val EMOJIS = ("😀 😂 😊 😍 😎 🥳 😭 😡 👍 👎 🙏 ❤️ 🔥 ✨ 🎉 💯 " +
                "🤔 😴 🤯 😅 🙌 👀 💀 💜 🐱 🐶 🌈 ⭐ 🍕 ☕ 🎮 🚀").split(" ")
        val EGG = listOf("L", "L", "L", ",", ".")
    }

    private class Key(val label: String, val type: Int, val w: Float = 1f, val icon: Int = -1, val act: Int = 0) {
        var x = 0f; var y = 0f; var wd = 0f; var h = 0f
        var down = 0f; var rippleT = 0L; var rx = 0f; var ry = 0f
        var on = 0f; var on2 = 0f
    }

    private class Row(val keys: List<Key>, val stretch: Boolean, val hw: Float = 1f)
    private class Undo(val orig: String, val fixed: String, val tail: String)
    private class Flake(var x: Float, var y: Float, val sz: Float, val vy: Float, val ph: Float, var rot: Float, val vr: Float)

    // ---- state ----
    private var theme = Themes.current(ctx)
    private var lang = "EN"
    private var mode = 0 // 0 letters, 1 symbols, 2 emoji, 3 widgets
    private var shift = false
    private var caps = false
    private var lastShift = 0L
    private var mascot = 1
    private var radius = 12
    private var gapH = 6
    private var gapV = 6
    private var autoOn = true
    private var haptic = true
    private var snowOn = false
    private var listening = false
    private var busy = false
    private var rows: List<Row> = emptyList()
    private var pressed: Key? = null
    private var popKey: Key? = null
    private var pop = 0f
    private var eggStart = 0L
    private var lastFrame = SystemClock.uptimeMillis()
    private val tokens = ArrayList<String>()

    // top bar
    private val wKey = Key("", WIDGETS)
    private val mKey = Key("", MIC)
    private val tools = listOf(
        Key("", TOOL, 1f, Ic.SMILE, A_EMOJI), Key("", TOOL, 1f, Ic.CLIP, A_CLIP),
        Key("", TOOL, 1f, Ic.TRANS, A_TRANS), Key("", TOOL, 1f, Ic.WAND, A_AUTO), Key("", TOOL, 1f, Ic.GEAR, A_GEAR)
    )
    private val sugg = List(3) { Key("", SUGG, 1f, -1, it) }
    private var topY = 0f; private var topH = 0f; private var pillL = 0f; private var pillR = 0f
    private var pillMix = 0f

    // autocorrect
    private var slots: Array<String?> = arrayOfNulls(3)
    private var autoWord: String? = null
    private var curWord = ""
    private var undo: Undo? = null

    // floating mascot
    private var mx = 0f; private var my = 0f; private var mvx = 0f; private var mvy = 0f
    private var tx = 0f; private var ty = 0f
    private var mInit = false
    private var lastTouch = 0L; private var mtap = 0L
    private var spin = 0f; private var spinV = 0f

    // snow
    private val flakes = ArrayList<Flake>()
    private val flakePath = Path().apply {
        for (i in 0 until 6) {
            val a = Math.toRadians(i * 60.0 - 90)
            val ca = cos(a).toFloat(); val sa = sin(a).toFloat()
            moveTo(0f, 0f); lineTo(ca, sa)
            val bx = ca * 0.62f; val by = sa * 0.62f
            for (sd in intArrayOf(-1, 1)) {
                val b = a + sd * Math.toRadians(50.0)
                moveTo(bx, by); lineTo(bx + cos(b).toFloat() * 0.32f, by + sin(b).toFloat() * 0.32f)
            }
        }
    }

    private val density = resources.displayMetrics.density
    private val fontScale = resources.configuration.fontScale
    private fun dp(v: Float) = v * density
    private fun sp(v: Float) = v * density * fontScale

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ip = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val snowP = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }
    private val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x33000000 }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private val eggPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val rect = RectF()
    private val path = Path()
    private val cookie = Path()
    private val matrix = Matrix()
    private var eggShader: BitmapShader? = null
    private val eggBmp: Bitmap? by lazy {
        try { BitmapFactory.decodeResource(resources, R.drawable.easter) } catch (e: Throwable) { null }
    }
    private val handler = Handler(Looper.getMainLooper())
    private val repeater = object : Runnable {
        override fun run() {
            l.onDelete()
            handler.postDelayed(this, 50)
        }
    }

    init { reload() }

    fun reload() {
        val p = prefs(context)
        theme = Themes.current(context)
        lang = (p.getString("lang", "EN") ?: "EN").let { if (it in Layouts.langs) it else "EN" }
        mascot = p.getInt("mascot", 1).coerceIn(0, Mascots.art.size - 1)
        radius = p.getInt("radius", 12)
        gapH = p.getInt("gap", 6)
        gapV = p.getInt("rowgap", 6)
        autoOn = p.getBoolean("autocorrect", true)
        haptic = p.getBoolean("haptic", true)
        snowOn = Themes.snowOn(context, theme)
        mode = 0; shift = false; caps = false
        undo = null
        clearSlots()
        AutoCorrect.warm(context, lang)
        rebuild()
    }

    fun setListening(b: Boolean) { listening = b; invalidate() }
    fun setBusy(b: Boolean) { busy = b; invalidate() }

    private fun chars(s: String) = s.map { Key(it.toString(), CHAR) }
    private fun bottomRow() = Row(listOf(Key("ABC", SYM, 1.5f), Key("", SPACE, 5f), Key("", DEL, 1.5f), Key("", ENTER, 1.5f)), true)

    private fun rebuild() {
        val rs = ArrayList<Row>()
        when (mode) {
            2 -> {
                EMOJIS.chunked(8).forEach { ch -> rs.add(Row(ch.map { Key(it, CHAR) }, true)) }
                rs.add(bottomRow())
            }
            3 -> {
                val tl = listOf(
                    Triple(Ic.WAND, "Autocorrect", A_AUTO), Triple(Ic.PAW, "Mascot", A_MASCOT),
                    Triple(Ic.PALETTE, "Theme", A_THEME), Triple(Ic.SNOW, "Snow", A_SNOW),
                    Triple(Ic.TRANS, "Translate", A_TLANG), Triple(Ic.VIBRATE, "Haptics", A_HAPTIC),
                    Triple(Ic.CLIP, "Paste", A_CLIP), Triple(Ic.GEAR, "Settings", A_GEAR)
                )
                tl.chunked(4).forEach { ch -> rs.add(Row(ch.map { Key(it.second, TILE, 1f, it.first, it.third) }, true, 2f)) }
                rs.add(bottomRow())
            }
            else -> {
                rs.add(Row(chars("1234567890"), true))
                if (mode == 0) {
                    val lt = Layouts.letters(lang)
                    rs.add(Row(chars(lt[0]), false))
                    rs.add(Row(chars(lt[1]), false))
                    rs.add(Row(listOf(Key("", SHIFT, 1.5f)) + chars(lt[2]) + Key("", DEL, 1.5f), false))
                } else {
                    val s = Layouts.symbols
                    rs.add(Row(chars(s[0]), false))
                    rs.add(Row(chars(s[1]), false))
                    rs.add(Row(listOf(Key("", SPACER, 1.5f)) + chars(s[2]) + Key("", DEL, 1.5f), false))
                }
                rs.add(Row(listOf(
                    Key(if (mode == 0) "?123" else "ABC", SYM, 1.5f), Key(",", CHAR), Key("", LANG, 1.2f),
                    Key("", SPACE, 4f), Key(".", CHAR), Key("", ENTER, 1.5f)
                ), true))
            }
        }
        rows = rs
        layoutKeys()
        invalidate()
    }

    private fun layoutKeys() {
        if (width == 0 || height == 0) return
        val padX = dp(3f); val padT = dp(4f); val padB = dp(8f)
        val total = TOP_HW + rows.fold(0f) { a, r -> a + r.hw }
        val unit = (height - padT - padB) / total
        topY = padT; topH = TOP_HW * unit
        wKey.x = padX; wKey.y = topY; wKey.wd = topH; wKey.h = topH
        mKey.x = width - padX - topH; mKey.y = topY; mKey.wd = topH; mKey.h = topH
        pillL = padX + topH + dp(2f); pillR = width - padX - topH - dp(2f)
        val tw = (pillR - pillL) / tools.size
        tools.forEachIndexed { i, k -> k.x = pillL + i * tw; k.y = topY; k.wd = tw; k.h = topH }
        val sw = (pillR - pillL) / 3f
        sugg.forEachIndexed { i, k -> k.x = pillL + i * sw; k.y = topY; k.wd = sw; k.h = topH }

        val avail = width - 2 * padX
        val maxSum = rows.filter { !it.stretch }.maxOfOrNull { r -> r.keys.fold(0f) { a, k -> a + k.w } } ?: 1f
        var y = topY + topH
        for (r in rows) {
            val sum = r.keys.fold(0f) { a, k -> a + k.w }
            val u = if (r.stretch) avail / sum else avail / maxSum
            var x = padX + (avail - sum * u) / 2
            val h = r.hw * unit
            for (k in r.keys) {
                k.x = x; k.y = y; k.wd = k.w * u; k.h = h
                x += k.wd
            }
            y += h
        }
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), (dp(46f) * 5.85f + dp(12f)).toInt())
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        layoutKeys()
    }

    private fun label(k: Key) = when (k.type) {
        CHAR -> if (shift || caps) k.label.uppercase() else k.label
        LANG -> lang
        SPACE -> Layouts.names[lang] ?: ""
        else -> k.label
    }

    private fun tileActive(act: Int) = when (act) {
        A_AUTO -> autoOn; A_MASCOT -> mascot != 0; A_SNOW -> snowOn; A_HAPTIC -> haptic; else -> false
    }

    private fun tileState(act: Int): String = when (act) {
        A_AUTO -> if (autoOn) "On" else "Off"
        A_MASCOT -> Mascots.names[mascot]
        A_THEME -> theme.name
        A_SNOW -> if (snowOn) "On" else "Off"
        A_TLANG -> { val t = prefs(context).getString("tlang", "auto") ?: "auto"; if (t == "auto") "Auto" else "to $t" }
        A_HAPTIC -> if (haptic) "On" else "Off"
        else -> ""
    }

    private fun clickT(k: Key, now: Long): Float {
        val v = (now - k.rippleT) / 450f
        return if (k.rippleT != 0L && v in 0f..1f) v else 0f
    }

    // ---- drawing ----
    override fun onDraw(c: Canvas) {
        val now = SystemClock.uptimeMillis()
        val dt = (now - lastFrame).coerceIn(1L, 50L).toFloat()
        lastFrame = now
        var anim = false
        c.drawColor(theme.bg)
        val kd = 1f - exp(-dt / 45f)

        if (drawTop(c, now, dt, kd)) anim = true
        for (r in rows) for (k in r.keys) {
            if (k.type == SPACER) continue
            if (drawKey(c, k, now, kd)) anim = true
        }
        if (snowOn) { updateSnow(dt / 1000f, now); drawSnow(c) }
        if (mascot != 0) { updateMascot(dt / 1000f, now); drawMascot(c, now) }
        if (drawPop(c, dt)) anim = true
        if (drawEgg(c, now)) anim = true

        if (anim || snowOn || mascot != 0 || listening || busy) postInvalidateOnAnimation()
    }

    private fun drawKey(c: Canvas, k: Key, now: Long, kd: Float): Boolean {
        var anim = false
        val tgt = if (k === pressed) 1f else 0f
        k.down += (tgt - k.down) * kd
        if (abs(tgt - k.down) > 0.01f) anim = true
        val onT = when (k.type) { SHIFT -> if (shift || caps) 1f else 0f; TILE -> if (tileActive(k.act)) 1f else 0f; else -> 0f }
        val capT = if (k.type == SHIFT && caps) 1f else 0f
        k.on += (onT - k.on) * kd * 0.6f
        k.on2 += (capT - k.on2) * kd * 0.6f
        if (abs(onT - k.on) > 0.01f || abs(capT - k.on2) > 0.01f) anim = true

        var s = 1f - 0.1f * k.down
        if (k.type == SHIFT) {
            val bt = (now - lastShift) / 280f
            if (bt in 0f..1f) { s += 0.12f * sin(bt * PI).toFloat(); anim = true }
        }
        val hx = (k.wd - dp(gapH.toFloat())) / 2 * s
        val hy = (k.h - dp(gapV.toFloat())) / 2 * s
        val cx = k.x + k.wd / 2
        val cy = k.y + k.h / 2
        rect.set(cx - hx, cy - hy, cx + hx, cy + hy)
        val rad = min(dp(if (k.type == TILE) 18f else radius.toFloat()), min(hx, hy))

        c.drawRoundRect(rect.left, rect.top + dp(1.2f), rect.right, rect.bottom + dp(1.2f), rad, rad, shadow)
        fill.color = when (k.type) {
            ENTER -> theme.accent
            SHIFT -> mixColor(theme.fn, theme.accent, 0.3f * k.on + 0.7f * k.on2)
            TILE -> mixColor(theme.key, theme.accent, k.on)
            SPACE, CHAR -> theme.key
            else -> theme.fn
        }
        c.drawRoundRect(rect, rad, rad, fill)
        if (k.down > 0.02f) {
            fill.color = theme.press
            fill.alpha = (130 * k.down).toInt()
            c.drawRoundRect(rect, rad, rad, fill)
            fill.alpha = 255
        }

        // Material ripple
        val rt = now - k.rippleT
        if (k.rippleT != 0L && rt < 380) {
            anim = true
            val p = rt / 380f
            path.reset()
            path.addRoundRect(rect, rad, rad, Path.Direction.CW)
            c.save()
            c.clipPath(path)
            fill.color = theme.accent
            fill.alpha = ((1f - p) * 90).toInt()
            c.drawCircle(k.rx, k.ry, p * k.wd * 0.9f + dp(6f), fill)
            fill.alpha = 255
            c.restore()
        }

        val ct = clickT(k, now)
        if (ct > 0f) anim = true
        val fg = when (k.type) {
            ENTER -> theme.onAccent
            SHIFT -> mixColor(mixColor(theme.text, theme.accent, k.on), theme.onAccent, k.on2)
            TILE -> mixColor(theme.text, theme.onAccent, k.on)
            else -> theme.text
        }
        ip.color = fg
        txt.color = fg
        when (k.type) {
            SHIFT -> Ic.draw(c, Ic.SHIFT, cx, cy, dp(24f), ip, 0f, k.on, k.on2)
            DEL -> Ic.draw(c, Ic.BACK, cx, cy, dp(24f), ip, ct)
            ENTER -> Ic.draw(c, Ic.ENTER, cx, cy, dp(24f), ip, ct)
            LANG -> {
                Ic.draw(c, Ic.GLOBE, cx, cy - dp(6f), dp(18f), ip, ct)
                txt.textSize = sp(9f)
                c.drawText(lang, cx, cy + dp(11f), txt)
            }
            TILE -> {
                Ic.draw(c, k.icon, cx, cy - hy * 0.28f, dp(28f), ip, ct)
                txt.textSize = sp(12f)
                c.drawText(k.label, cx, cy + hy * 0.42f, txt)
                txt.textSize = sp(10f); txt.alpha = 170
                c.drawText(tileState(k.act), cx, cy + hy * 0.72f, txt)
                txt.alpha = 255
            }
            else -> {
                val size = if (k.type == CHAR) 22f else 14f
                txt.textSize = sp(size) * (1f - 0.06f * k.down)
                val ty = rect.centerY() - (txt.fontMetrics.ascent + txt.fontMetrics.descent) / 2
                c.drawText(label(k), rect.centerX(), ty, txt)
            }
        }
        return anim
    }

    private fun touchFx(c: Canvas, k: Key, cx: Float, cy: Float, r: Float, now: Long, kd: Float, alpha: Float): Boolean {
        var anim = false
        val tgt = if (k === pressed) 1f else 0f
        k.down += (tgt - k.down) * kd
        if (abs(tgt - k.down) > 0.01f) anim = true
        if (k.down > 0.02f) {
            fill.color = theme.press; fill.alpha = (110 * k.down * alpha).toInt()
            c.drawCircle(cx, cy, r * 0.95f, fill)
        }
        val rt = now - k.rippleT
        if (k.rippleT != 0L && rt < 380) {
            anim = true
            val p = rt / 380f
            fill.color = theme.accent; fill.alpha = ((1f - p) * 90 * alpha).toInt()
            c.drawCircle(cx, cy, p * r * 1.3f + dp(4f), fill)
        }
        fill.alpha = 255
        return anim
    }

    private fun drawTop(c: Canvas, now: Long, dt: Float, kd: Float): Boolean {
        var anim = false
        val tm = if (slots.any { it != null }) 1f else 0f
        pillMix += (tm - pillMix) * (1f - exp(-dt / 70f))
        if (abs(tm - pillMix) > 0.01f) anim = true
        val cy = topY + topH / 2
        val hh = topH * 0.43f

        rect.set(pillL, cy - hh, pillR, cy + hh)
        fill.color = theme.fn
        c.drawRoundRect(rect, hh, hh, fill)
        path.reset(); path.addRoundRect(rect, hh, hh, Path.Direction.CW)
        c.save(); c.clipPath(path)

        val ta = 1f - pillMix
        if (ta > 0.02f) for (k in tools) {
            val ccx = k.x + k.wd / 2
            if (touchFx(c, k, ccx, cy, hh, now, kd, ta)) anim = true
            val ct = clickT(k, now)
            if (ct > 0f) anim = true
            var col = theme.text
            if (k.act == A_AUTO) col = if (autoOn) theme.accent else mixColor(theme.text, theme.fn, 0.6f)
            ip.color = col; ip.alpha = (255 * ta).toInt()
            val t = if (k.act == A_TRANS && busy) (now % 900) / 900f else ct
            Ic.draw(c, k.icon, ccx, cy, dp(23f), ip, t)
        }
        if (pillMix > 0.02f) for (i in 0..2) {
            val s = slots[i] ?: continue
            val k = sugg[i]
            val ccx = k.x + k.wd / 2
            if (touchFx(c, k, ccx, cy, hh, now, kd, pillMix)) anim = true
            val hot = i == 1 && autoWord != null
            if (hot) {
                fill.color = theme.accent; fill.alpha = (60 * pillMix).toInt()
                rect.set(k.x + dp(4f), cy - hh + dp(4f), k.x + k.wd - dp(4f), cy + hh - dp(4f))
                c.drawRoundRect(rect, hh, hh, fill); fill.alpha = 255
            }
            val shown = if (i == 0 && autoWord != null) "\u201C$s\u201D" else s
            txt.color = if (hot) theme.accent else theme.text
            txt.alpha = (255 * pillMix).toInt()
            txt.isFakeBoldText = i == 1
            txt.textSize = sp(16f)
            val m = txt.measureText(shown); val maxW = k.wd - dp(14f)
            if (m > maxW) txt.textSize = txt.textSize * maxW / m
            c.drawText(shown, ccx, cy - (txt.fontMetrics.ascent + txt.fontMetrics.descent) / 2, txt)
            txt.isFakeBoldText = false; txt.alpha = 255
            if (i > 0) {
                fill.color = theme.text; fill.alpha = (40 * pillMix).toInt()
                c.drawRect(k.x - dp(0.5f), cy - hh * 0.55f, k.x + dp(0.5f), cy + hh * 0.55f, fill)
                fill.alpha = 255
            }
        }
        c.restore()

        val w3 = mode == 3
        if (cookieBtn(c, wKey, if (w3) theme.accent else theme.key, if (w3) theme.onAccent else theme.text,
                if (w3) Ic.CHEV else Ic.GRID, 0f, now, kd, false, false)) anim = true
        if (cookieBtn(c, mKey, theme.accent, theme.onAccent, Ic.MIC, if (listening) 1f else 0f, now, kd, listening, listening)) anim = true
        return anim
    }

    private fun cookieBtn(c: Canvas, k: Key, col: Int, icCol: Int, icon: Int, a: Float, now: Long, kd: Float, spinning: Boolean, ring: Boolean): Boolean {
        var anim = false
        val tgt = if (k === pressed) 1f else 0f
        k.down += (tgt - k.down) * kd
        if (abs(tgt - k.down) > 0.01f) anim = true
        val cx = k.x + k.wd / 2; val cy = k.y + k.h / 2
        val ct = clickT(k, now)
        if (ct > 0f) anim = true
        val rr = min(k.wd, k.h) * 0.46f * (1f - 0.1f * k.down)
        val rot = k.down * 0.5f + (if (spinning) now / 800f else ct * 1.6f)
        cookie.reset()
        for (i in 0..96) {
            val an = (2 * PI * i / 96).toFloat()
            val r = rr * (1f + 0.06f * cos(8f * (an + rot)))
            val x = cx + r * cos(an); val y = cy + r * sin(an)
            if (i == 0) cookie.moveTo(x, y) else cookie.lineTo(x, y)
        }
        cookie.close()
        fill.color = col
        c.drawPath(cookie, fill)
        if (ring) {
            val ph = (now % 1200) / 1200f
            ringP.color = theme.accent; ringP.alpha = ((1f - ph) * 150).toInt(); ringP.strokeWidth = dp(2f)
            c.drawCircle(cx, cy, rr * (1f + 0.45f * ph), ringP)
        }
        ip.color = icCol
        Ic.draw(c, icon, cx, cy, dp(24f), ip, if (spinning) 0f else ct, a)
        return anim
    }

    // ---- floating mascot ----
    private fun pointMascot(k: Key, now: Long) {
        lastTouch = now; mtap = now
        val cxk = k.x + k.wd / 2
        val side = if (cxk < width / 2f) 1f else -1f
        val half = dp(22f)
        tx = (cxk + side * dp(34f)).coerceIn(half, width - half)
        ty = (k.y + k.h * 0.1f - dp(10f)).coerceIn(half, height - half)
        spinV += side * 900f
    }

    private fun updateMascot(dt: Float, now: Long) {
        if (width == 0) return
        if (!mInit) { mx = width * 0.5f; my = height * 0.62f; tx = mx; ty = my; mInit = true }
        if (now - lastTouch > 1500) {
            val t = now / 1000f
            tx = width * (0.5f + 0.38f * sin(t * 0.55f))
            ty = height * (0.58f + 0.28f * sin(t * 0.83f + 1f))
        }
        mvx += ((tx - mx) * 70f - mvx * 10f) * dt
        mvy += ((ty - my) * 70f - mvy * 10f) * dt
        mx += mvx * dt; my += mvy * dt
        spinV += (-spin * 60f - spinV * 7f) * dt
        spin += spinV * dt
    }

    private fun drawMascot(c: Canvas, now: Long) {
        val art = Mascots.art[mascot]
        if (art.isEmpty() || !mInit) return
        val cell = dp(3.1f)
        val w = art[0].length * cell; val h = art.size * cell
        val bob = sin(now / 380.0).toFloat() * dp(3f)
        val sway = sin(now / 650.0).toFloat() * 5f
        val tilt = (mvx / dp(260f)).coerceIn(-1f, 1f) * 24f
        val st = (now - mtap) / 340f
        val sq = if (st in 0f..1f) 0.2f * sin(st * PI * 2).toFloat() * (1f - st) else 0f
        val blink = now % 3600 < 130
        fill.color = theme.accent; fill.alpha = 36
        c.drawCircle(mx, my + bob, w * 0.75f, fill)
        fill.alpha = 255
        c.save()
        c.translate(mx, my + bob)
        c.rotate(tilt + sway + spin)
        c.scale(1f + sq, 1f - sq)
        Mascots.drawArt(c, fill, mascot, -w / 2, -h / 2, cell, theme.accent, blink)
        c.restore()
    }

    // ---- snow ----
    private fun newFlake(anywhere: Boolean): Flake {
        val sz = dp(3.5f) + Random.nextFloat() * dp(6f)
        return Flake(Random.nextFloat() * width, if (anywhere) Random.nextFloat() * height else -sz, sz,
            dp(26f) + Random.nextFloat() * dp(40f), Random.nextFloat() * 6.28f, Random.nextFloat() * 360f,
            (Random.nextFloat() - 0.5f) * 140f)
    }

    private fun updateSnow(dt: Float, now: Long) {
        if (width == 0) return
        if (flakes.isEmpty()) repeat(28) { flakes.add(newFlake(true)) }
        for (i in flakes.indices) {
            val f = flakes[i]
            f.y += f.vy * dt
            f.x += sin(now / 1000f * 0.9f + f.ph) * dp(16f) * dt
            f.rot += f.vr * dt
            if (f.y > height + f.sz) flakes[i] = newFlake(false)
        }
    }

    private fun drawSnow(c: Canvas) {
        val col = if (Color.luminance(theme.bg) > 0.6f) theme.accent else Color.WHITE
        for (f in flakes) {
            snowP.color = col; snowP.alpha = 215
            if (f.sz < dp(5.5f)) {
                snowP.style = Paint.Style.FILL
                c.drawCircle(f.x, f.y, f.sz * 0.3f, snowP)
            } else {
                snowP.style = Paint.Style.STROKE
                snowP.strokeWidth = dp(1.3f) / f.sz
                c.save(); c.translate(f.x, f.y); c.rotate(f.rot); c.scale(f.sz, f.sz)
                c.drawPath(flakePath, snowP)
                c.restore()
            }
        }
    }

    private fun drawPop(c: Canvas, dt: Float): Boolean {
        val pk = popKey ?: return false
        pop += ((if (pressed === pk) 1f else 0f) - pop) * (1f - exp(-dt / 55f))
        if (pressed !== pk && pop < 0.03f) { popKey = null; pop = 0f; return false }
        val rr = dp(30f) * pop
        val cx = (pk.x + pk.wd / 2).coerceIn(dp(32f), width - dp(32f))
        val cy = max(pk.y - dp(26f), dp(32f))
        val rot = (1f - pop) * 1.4f
        cookie.reset()
        for (i in 0..96) {
            val a = (2 * PI * i / 96).toFloat()
            val r = rr * (1f + 0.075f * cos(7f * (a + rot)))
            val x = cx + r * cos(a)
            val y = cy + r * sin(a)
            if (i == 0) cookie.moveTo(x, y) else cookie.lineTo(x, y)
        }
        cookie.close()
        fill.color = theme.accent
        c.drawPath(cookie, fill)
        txt.color = theme.onAccent
        txt.textSize = sp(28f) * max(pop, 0.2f)
        c.drawText(label(pk), cx, cy - (txt.fontMetrics.ascent + txt.fontMetrics.descent) / 2, txt)
        return true
    }

    private fun drawEgg(c: Canvas, now: Long): Boolean {
        if (eggStart == 0L) return false
        val t = now - eggStart
        val bmp = eggBmp
        if (t > 3300 || bmp == null) { eggStart = 0L; return false }
        val p = min(1f, t / 450f)
        val q = p - 1f
        val sc = 1f + 2.70158f * q * q * q + 1.70158f * q * q
        val fade = if (t > 2900) 1f - (t - 2900) / 400f else 1f
        fill.color = Color.BLACK
        fill.alpha = (170 * fade).toInt()
        c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), fill)
        val d = min(width, height) * 0.62f * sc
        val cx = width / 2f
        val cy = height / 2f - dp(8f)
        fill.color = theme.accent
        fill.alpha = (255 * fade).toInt()
        c.drawCircle(cx, cy, d / 2 + dp(4f), fill)
        fill.alpha = 255
        val sh = eggShader ?: BitmapShader(bmp, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP).also { eggShader = it }
        matrix.setScale(d / bmp.width, d / bmp.height)
        matrix.postTranslate(cx - d / 2, cy - d / 2)
        sh.setLocalMatrix(matrix)
        eggPaint.shader = sh
        eggPaint.alpha = (255 * fade).toInt()
        c.drawCircle(cx, cy, d / 2, eggPaint)
        txt.color = Color.WHITE
        txt.alpha = (255 * fade).toInt()
        txt.textSize = sp(15f)
        c.drawText("made with vibes ✨", cx, cy + d / 2 + dp(24f), txt)
        return true
    }

    private fun find(x: Float, y: Float): Key? {
        if (y < topY + topH) {
            if (x < pillL) return wKey
            if (x >= pillR) return mKey
            val list = if (pillMix > 0.5f) sugg.filter { slots[it.act] != null } else tools
            return list.firstOrNull { x >= it.x && x < it.x + it.wd }
        }
        val row = rows.firstOrNull { y < it.keys[0].y + it.keys[0].h } ?: rows.lastOrNull() ?: return null
        return row.keys.firstOrNull { it.type != SPACER && x >= it.x && x < it.x + it.wd }
    }

    private fun track(tok: String) {
        tokens.add(tok)
        if (tokens.size > EGG.size) tokens.removeAt(0)
        if (tokens == EGG) { tokens.clear(); eggStart = SystemClock.uptimeMillis() }
    }

    // ---- autocorrect ----
    private fun clearSlots() { slots = arrayOfNulls(3); autoWord = null; curWord = "" }

    private fun refresh() {
        if (!autoOn || mode != 0) { clearSlots(); invalidate(); return }
        val before = l.textBefore(40)
        var i = before.length
        while (i > 0 && before[i - 1].isLetter()) i--
        val w = before.substring(i)
        val prev = if (i > 0) before[i - 1] else ' '
        if (w.isEmpty() || prev == '\'' || prev == '\u2019' || prev.isDigit()) { clearSlots(); invalidate(); return }
        val r = AutoCorrect.suggest(context, lang, w)
        curWord = w
        slots = r.slots
        val head = before.substring(0, i).trimEnd()
        val sentenceStart = head.isEmpty() || head.last() in ".!?\n"
        val proper = w.length > 1 && w[0].isUpperCase() && !sentenceStart
        val acronym = w.length > 1 && w.all { it.isUpperCase() }
        autoWord = if (w.length >= 3 && !proper && !acronym) r.auto else null
        invalidate()
    }

    /** Commits [tail], first replacing the current word with its correction when autocorrect applies. */
    private fun applyAuto(tail: String) {
        val fix = autoWord
        if (autoOn && mode == 0 && fix != null && curWord.length >= 3) {
            val out = AutoCorrect.cased(curWord, fix)
            l.replace(curWord.length, out + tail)
            undo = Undo(curWord, out, tail)
        } else {
            if (tail.isNotEmpty()) l.onText(tail)
            undo = null
        }
        clearSlots()
    }

    private fun acceptSlot(i: Int) {
        val s = slots[i] ?: return
        l.replace(curWord.length, "$s ")
        if (s.equals(curWord, true)) AutoCorrect.learn(context, curWord)
        undo = null
        clearSlots()
    }

    private fun doUndo() {
        val u = undo ?: return
        undo = null
        l.replace(u.fixed.length + u.tail.length, u.orig + u.tail)
        AutoCorrect.learn(context, u.orig)
        post { refresh() }
    }

    private fun doAction(act: Int) {
        val p = prefs(context)
        val now = SystemClock.uptimeMillis()
        when (act) {
            A_EMOJI -> { mode = 2; clearSlots(); rebuild() }
            A_CLIP -> l.onPaste()
            A_TRANS -> if (!busy) l.onTranslate()
            A_AUTO -> { autoOn = !autoOn; p.edit().putBoolean("autocorrect", autoOn).apply(); clearSlots() }
            A_GEAR -> l.onSettings()
            A_MASCOT -> {
                mascot = (mascot + 1) % Mascots.art.size
                p.edit().putInt("mascot", mascot).apply()
                mtap = now; spinV += 900f
            }
            A_THEME -> {
                val cur = if (p.getBoolean("custom", false)) -1 else p.getInt("theme", 0)
                val nx = (cur + 1) % Themes.presets.size
                p.edit().putBoolean("custom", false).putInt("theme", nx).apply()
                theme = Themes.current(context)
                snowOn = Themes.snowOn(context, theme)
            }
            A_SNOW -> {
                p.edit().putInt("snow", if (snowOn) 0 else 1).apply()
                snowOn = Themes.snowOn(context, theme)
            }
            A_TLANG -> {
                val order = listOf("auto", "EN", "ES", "RU")
                val cur = p.getString("tlang", "auto") ?: "auto"
                p.edit().putString("tlang", order[(order.indexOf(cur) + 1) % order.size]).apply()
            }
            A_HAPTIC -> { haptic = !haptic; p.edit().putBoolean("haptic", haptic).apply() }
        }
    }

    private fun commit(k: Key) {
        undo = null
        when (k.type) {
            CHAR -> {
                val ch = label(k)
                if (mode != 2 && ch.length == 1 && !ch[0].isLetterOrDigit() && ch != "'") applyAuto(ch) else l.onText(ch)
                if (shift && !caps) shift = false
            }
            SHIFT -> {
                val now = SystemClock.uptimeMillis()
                if (caps) { caps = false; shift = false }
                else if (shift && now - lastShift < 350) caps = true
                else shift = !shift
                lastShift = now
            }
            SYM -> { mode = if (mode == 0) 1 else 0; clearSlots(); rebuild() }
            LANG -> {
                val i = Layouts.langs.indexOf(lang)
                lang = Layouts.langs[(i + 1) % Layouts.langs.size]
                prefs(context).edit().putString("lang", lang).apply()
                AutoCorrect.warm(context, lang)
                mode = 0; shift = false; caps = false
                clearSlots()
                rebuild()
            }
            SPACE -> applyAuto(" ")
            ENTER -> { applyAuto(""); undo = null; l.onEnter() }
            WIDGETS -> { mode = if (mode == 3) 0 else 3; clearSlots(); rebuild() }
            MIC -> { if (listening) listening = false else { listening = true; l.onVoice() } }
            TOOL, TILE -> doAction(k.act)
            SUGG -> acceptSlot(k.act)
        }
        track(when (k.type) { CHAR -> k.label.lowercase(); LANG -> "L"; else -> "x" })
        refresh()
        invalidate()
    }

    private fun setPressed(k: Key?, x: Float, y: Float) {
        pressed = k
        if (k != null) {
            val now = SystemClock.uptimeMillis()
            k.rippleT = now; k.rx = x; k.ry = y
            if (k.type == CHAR) popKey = k
            if (mascot != 0 && mInit) pointMascot(k, now)
        }
        invalidate()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (eggStart != 0L) { eggStart = 0L; invalidate(); return true }
                val k = find(e.x, e.y)
                setPressed(k, e.x, e.y)
                if (k != null) {
                    if (haptic) performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    if (k.type == DEL) {
                        if (undo != null) doUndo()
                        else {
                            l.onDelete()
                            handler.postDelayed(repeater, 400)
                        }
                    }
                }
            }
            MotionEvent.ACTION_MOVE -> {
                val k = find(e.x, e.y)
                if (k !== pressed) {
                    handler.removeCallbacks(repeater)
                    setPressed(k, e.x, e.y)
                }
            }
            MotionEvent.ACTION_UP -> {
                handler.removeCallbacks(repeater)
                val k = pressed
                pressed = null
                if (k != null && k.type != DEL) commit(k)
                else { if (k != null) post { refresh() }; invalidate() }
            }
            MotionEvent.ACTION_CANCEL -> {
                handler.removeCallbacks(repeater)
                pressed = null
                invalidate()
            }
        }
        return true
    }

    override fun onDetachedFromWindow() {
        handler.removeCallbacks(repeater)
        super.onDetachedFromWindow()
    }
}
