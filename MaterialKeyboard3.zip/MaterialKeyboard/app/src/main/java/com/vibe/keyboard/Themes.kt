package com.vibe.keyboard

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint

data class KbTheme(
    val name: String, val bg: Int, val key: Int, val fn: Int,
    val text: Int, val accent: Int, val onAccent: Int, val press: Int,
    val snow: Boolean = false
)

fun prefs(ctx: Context): SharedPreferences = ctx.getSharedPreferences("vibe", Context.MODE_PRIVATE)

fun mixColor(a: Int, b: Int, t: Float): Int {
    val k = t.coerceIn(0f, 1f)
    return Color.argb(
        (Color.alpha(a) + (Color.alpha(b) - Color.alpha(a)) * k).toInt(),
        (Color.red(a) + (Color.red(b) - Color.red(a)) * k).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * k).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * k).toInt()
    )
}

fun shadeColor(c: Int, f: Float) = Color.argb(
    Color.alpha(c), (Color.red(c) * f).toInt().coerceIn(0, 255),
    (Color.green(c) * f).toInt().coerceIn(0, 255), (Color.blue(c) * f).toInt().coerceIn(0, 255)
)

object Themes {
    private fun t(n: String, bg: String, k: String, f: String, tx: String, a: String, oa: String, p: String, snow: Boolean = false) =
        KbTheme(n, Color.parseColor(bg), Color.parseColor(k), Color.parseColor(f),
            Color.parseColor(tx), Color.parseColor(a), Color.parseColor(oa), Color.parseColor(p), snow)

    val presets = listOf(
        t("Vibe Dark", "#1B1A22", "#34313F", "#262330", "#EDE7F6", "#CFBCFF", "#381E72", "#6F6A80"),
        t("Light", "#ECEFF1", "#FFFFFF", "#CFD8DC", "#212121", "#1976D2", "#FFFFFF", "#90A4AE"),
        t("AMOLED", "#000000", "#1A1A1A", "#0D0D0D", "#FFFFFF", "#00E676", "#000000", "#444444"),
        t("Lavender", "#EDE7F6", "#FFFFFF", "#D1C4E9", "#311B92", "#673AB7", "#FFFFFF", "#9575CD"),
        t("Forest", "#E8F5E9", "#FFFFFF", "#C8E6C9", "#1B5E20", "#2E7D32", "#FFFFFF", "#81C784"),
        t("Sunset", "#2B1B17", "#4E342E", "#3E2723", "#FFE0B2", "#FF9800", "#261300", "#8D6E63"),
        t("Winter", "#0D1B2E", "#1D3552", "#142A44", "#E8F4FF", "#8FD3FF", "#06304D", "#4A7BA8", true),
        t("Frost", "#E3F2FD", "#FFFFFF", "#BBDEFB", "#0D2B45", "#2196F3", "#FFFFFF", "#64B5F6", true)
    )

    fun fromSeed(seed: Int, dark: Boolean): KbTheme {
        val hsv = FloatArray(3)
        Color.colorToHSV(seed, hsv)
        val h = hsv[0]
        fun c(s: Float, v: Float) = Color.HSVToColor(floatArrayOf(h, s, v))
        return if (dark)
            KbTheme("Custom", c(.18f, .11f), c(.16f, .24f), c(.20f, .17f), c(.10f, .95f), c(.45f, .98f), c(.90f, .20f), c(.30f, .55f))
        else
            KbTheme("Custom", c(.10f, .96f), c(.04f, 1f), c(.16f, .88f), c(.30f, .15f), c(.85f, .65f), Color.WHITE, c(.35f, .75f))
    }

    fun current(ctx: Context): KbTheme {
        val p = prefs(ctx)
        return if (p.getBoolean("custom", false))
            fromSeed(p.getInt("seed", Color.parseColor("#6750A4")), p.getBoolean("dark", true))
        else presets[p.getInt("theme", 0).coerceIn(0, presets.size - 1)]
    }

    /** Is falling snow on? pref -1 = follow the theme, 0 = off, 1 = on */
    fun snowOn(ctx: Context, th: KbTheme): Boolean {
        val s = prefs(ctx).getInt("snow", -1)
        return if (s == -1) th.snow else s == 1
    }
}

object Layouts {
    val langs = listOf("EN", "ES", "RU")
    val names = mapOf("EN" to "English", "ES" to "Español", "RU" to "Русский")
    val tags = mapOf("EN" to "en-US", "ES" to "es-ES", "RU" to "ru-RU")

    fun letters(l: String): List<String> = when (l) {
        "ES" -> listOf("qwertyuiop", "asdfghjklñ", "zxcvbnm")
        "RU" -> listOf("йцукенгшщзхъ", "фывапролджэё", "ячсмитьбю")
        else -> listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
    }

    val symbols = listOf("@#\$%&-+()/", "~=_<>[]{}|", "*\"':;!?")
}

/**
 * Pixel pets, 12 columns wide.
 * o outline · b body · l highlight · s shade · e eye · h eye shine · g visor glow · k dark · p blush · w white
 */
object Mascots {
    val names = listOf("Off", "Cat", "Ghost", "Slime", "Robot", "Alien")
    val art: List<List<String>> = listOf(
        emptyList(),
        listOf( // Cat
            ".oo......oo.", "obbo....obbo", "obbbooooobbo", "obbbbbbbbbbo", "obbehbbehbbo",
            "obbbbbkbbbbo", "obpbbwwwbpbo", ".obbbbbbbbo.", "..oooooooo.."
        ),
        listOf( // Ghost
            "...oooooo...", "..obbbbbbo..", ".oblbbbbbbo.", "obbbbbbbbbbo", "obbehbbehbbo",
            "obbbbbbbbbbo", "obpbbkkbbpbo", "obbbbbbbbbbo", "obbbbbbbbbbo", "obbobbbbobbo", ".oo.oooo.oo."
        ),
        listOf( // Slime
            "....oooo....", "..ooblbbo...", ".obbbbbbbbo.", ".obehbbehbbo", "obbbbbbbbbbo",
            "obpbbkkbbpbo", "obbbbbbbbbbo", ".oooooooooo."
        ),
        listOf( // Robot
            ".....kk.....", ".....oo.....", "..oooooooo..", ".obbbbbbbbo.", "obkkkkkkkkbo",
            "obkggkkggkbo", "obkkkkkkkkbo", ".obbbbbbbbo.", "..obbddbbo..", "..obbbbbbo..", "..oo....oo.."
        ),
        listOf( // Alien
            "...oooooo...", "..obbbbbbo..", ".obbbbbbbbo.", "obbehbbehbbo", "obbbbbbbbbbo",
            "obbbbkkbbbbo", ".obbbbbbbbo.", ".obobobobobo", ".o.o.o.o.o.o"
        )
    )

    fun drawArt(c: Canvas, p: Paint, idx: Int, left: Float, top: Float, cell: Float, accent: Int, blink: Boolean) {
        val a = art.getOrNull(idx) ?: return
        val outline = shadeColor(accent, 0.38f)
        val hi = mixColor(accent, Color.WHITE, 0.5f)
        val sh = shadeColor(accent, 0.72f)
        val dark = Color.parseColor("#1A1420")
        for (r in a.indices) for (col in a[r].indices) {
            val ch = a[r][col]
            val color = when (ch) {
                '.' -> continue
                'o' -> outline
                'b' -> accent
                'l' -> hi
                's', 'd' -> sh
                'e' -> if (blink) outline else dark
                'h' -> if (blink) outline else Color.WHITE
                'g' -> if (blink) dark else Color.parseColor("#B8F5FF")
                'k' -> dark
                'p' -> Color.parseColor("#FF8FA3")
                'w' -> Color.WHITE
                else -> accent
            }
            p.color = color
            val x = left + col * cell; val y = top + r * cell
            c.drawRect(x, y, x + cell + 0.6f, y + cell + 0.6f, p)
        }
    }
}
