package com.vibe.keyboard

import android.content.Context
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions

/** On-device translation (ML Kit). Language packs download once, then it works offline. */
object Tr {
    private val cache = HashMap<String, Translator>()

    private fun code(l: String) = when (l) {
        "ES" -> TranslateLanguage.SPANISH
        "RU" -> TranslateLanguage.RUSSIAN
        else -> TranslateLanguage.ENGLISH
    }

    /** Target language: pref "tlang" = auto | EN | ES | RU. */
    fun target(ctx: Context, src: String): String {
        val t = prefs(ctx).getString("tlang", "auto") ?: "auto"
        if (t != "auto" && t != src) return t
        return if (src == "EN") "ES" else "EN"
    }

    fun run(src: String, dst: String, text: String, ok: (String) -> Unit, fail: (Exception) -> Unit) {
        val tr = cache.getOrPut("$src>$dst") {
            Translation.getClient(
                TranslatorOptions.Builder().setSourceLanguage(code(src)).setTargetLanguage(code(dst)).build()
            )
        }
        tr.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener { tr.translate(text).addOnSuccessListener { ok(it) }.addOnFailureListener { fail(it) } }
            .addOnFailureListener { fail(it) }
    }
}
