package com.vibe.keyboard

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

// ---------- small custom views ----------

/** Draws one of the vector icons and can play its click animation. */
class IconView(ctx: Context, private val icon: Int, color: Int) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color }
    private var t = 0f
    private var anim: ValueAnimator? = null

    fun play() {
        anim?.cancel()
        anim = ValueAnimator.ofFloat(0.001f, 1f).apply {
            duration = 520
            addUpdateListener { t = it.animatedValue as Float; invalidate() }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: Animator) { t = 0f; invalidate() }
            })
            start()
        }
    }

    override fun onDraw(c: Canvas) {
        Ic.draw(c, icon, width / 2f, height / 2f, min(width, height).toFloat(), p, t)
    }
}

/** Rounded tinted square holding an icon. */
class Chip(ctx: Context, icon: Int, tint: Int, size: Int = 40) : FrameLayout(ctx) {
    val icon: IconView = IconView(ctx, icon, tint)

    init {
        val d = resources.displayMetrics.density
        background = GradientDrawable().apply {
            cornerRadius = 14 * d
            setColor(Color.argb(38, Color.red(tint), Color.green(tint), Color.blue(tint)))
        }
        val s = (size * 0.56f * d).toInt()
        addView(this.icon, LayoutParams(s, s, Gravity.CENTER))
    }
}

/** Floating, blinking pixel pet. */
class MascotView(ctx: Context, private val idx: Int, private val accent: Int, private val cellDp: Float, private val floating: Boolean) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(c: Canvas) {
        val art = Mascots.art.getOrNull(idx) ?: return
        if (art.isEmpty()) return
        val d = resources.displayMetrics.density
        val cell = cellDp * d
        val w = art[0].length * cell; val h = art.size * cell
        val now = SystemClock.uptimeMillis()
        val bob = if (floating) sin(now / 400.0).toFloat() * 3f * d else 0f
        c.save()
        c.translate(width / 2f, height / 2f + bob)
        if (floating) c.rotate(sin(now / 700.0).toFloat() * 6f)
        Mascots.drawArt(c, p, idx, -w / 2, -h / 2, cell, accent, now % 3600 < 130)
        c.restore()
        if (floating) postInvalidateOnAnimation()
    }
}

/** Mini keyboard preview of a theme. */
class Swatch(ctx: Context, private val th: KbTheme, private val isSel: Boolean) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    override fun onDraw(c: Canvas) {
        val d = resources.displayMetrics.density
        val w = width.toFloat(); val h = height.toFloat()
        r.set(0f, 0f, w, h)
        p.style = Paint.Style.FILL; p.color = th.bg
        c.drawRoundRect(r, 16 * d, 16 * d, p)
        val pad = 8 * d
        val kh = (h - pad * 2 - 3 * 4 * d) / 3.4f
        // pill row
        p.color = th.fn
        r.set(pad, pad, w - pad, pad + kh)
        c.drawRoundRect(r, kh / 2, kh / 2, p)
        p.color = th.accent
        c.drawCircle(w - pad - kh / 2, pad + kh / 2, kh * 0.42f, p)
        for (row in 0..1) {
            val y = pad + (kh + 4 * d) * (row + 1)
            val n = 5
            val kw = (w - pad * 2 - (n - 1) * 3 * d) / n
            for (i in 0 until n) {
                p.color = if (row == 1 && i == n - 1) th.accent else th.key
                r.set(pad + i * (kw + 3 * d), y, pad + i * (kw + 3 * d) + kw, y + kh * 0.9f)
                c.drawRoundRect(r, 4 * d, 4 * d, p)
            }
        }
        if (th.snow) {
            p.color = Color.WHITE; p.alpha = 220
            for (i in 0 until 6) c.drawCircle(w * (0.12f + 0.16f * i), h * (0.3f + 0.4f * ((i * 37) % 10) / 10f), 1.8f * d, p)
            p.alpha = 255
        }
        p.style = Paint.Style.STROKE
        if (isSel) {
            p.strokeWidth = 3 * d; p.color = th.accent
            r.set(1.5f * d, 1.5f * d, w - 1.5f * d, h - 1.5f * d)
            c.drawRoundRect(r, 15 * d, 15 * d, p)
            p.style = Paint.Style.FILL
            c.drawCircle(w - 14 * d, h - 14 * d, 10 * d, p)
            p.color = th.onAccent
            Ic.draw(c, Ic.CHECK, w - 14 * d, h - 14 * d, 14 * d, p)
        } else {
            p.strokeWidth = 1 * d; p.color = 0x22000000
            r.set(0.5f * d, 0.5f * d, w - 0.5f * d, h - 0.5f * d)
            c.drawRoundRect(r, 16 * d, 16 * d, p)
        }
    }
}

// ---------- activity ----------

class MainActivity : Activity() {
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val ink = Color.parseColor("#1C1B1F")
    private val subC = Color.parseColor("#6B6475")
    private val purple = Color.parseColor("#6750A4")
    private val pink = Color.parseColor("#D1305E")
    private val teal = Color.parseColor("#0E9F8E")
    private val orange = Color.parseColor("#F57C00")
    private val blue = Color.parseColor("#1E88E5")
    private val green = Color.parseColor("#2E9E5B")
    private val indigo = Color.parseColor("#4F5BD5")
    private val palette = listOf(
        "#6750A4", "#8E4EC6", "#AE2A8C", "#D1305E", "#E5484D", "#F76B15",
        "#FFA000", "#E5B813", "#8DC63F", "#30A46C", "#12A594", "#0BA5C4",
        "#0090FF", "#3E63DD", "#5B5BD6", "#795548", "#607D8B", "#1C1C24"
    )
    private lateinit var preview: KeyboardView
    private lateinit var input: EditText
    private lateinit var body: LinearLayout
    private var hexField: EditText? = null
    private var taps = 0
    private var firstRender = true
    private var bounceKey: String? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun lp(top: Int = 0) = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(top) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#4A3A8C")
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#F6F2FA"))
        }
        input = EditText(this).apply {
            hint = "Test the keyboard here…"
            showSoftInputOnFocus = false
            setPadding(dp(16), dp(10), dp(16), dp(10))
            setBackgroundColor(Color.WHITE)
        }
        preview = KeyboardView(this, object : KeyboardView.Listener {
            override fun onText(t: String) { input.append(t) }
            override fun onDelete() {
                val s = input.text
                if (s.isNotEmpty()) s.delete(s.length - 1, s.length)
            }
            override fun onEnter() { input.append("\n") }
            override fun onPaste() {}
            override fun onSettings() {}
            override fun textBefore(n: Int): String = input.text.toString().takeLast(n)
            override fun replace(len: Int, s: String) {
                val t = input.text
                t.delete(max(0, t.length - len), t.length)
                t.append(s)
            }
            override fun onVoice() {
                VoiceBridge.onResult = { t ->
                    VoiceBridge.onResult = null
                    preview.setListening(false)
                    if (!t.isNullOrEmpty()) input.append("$t ")
                }
                val lang = prefs(this@MainActivity).getString("lang", "EN") ?: "EN"
                startActivity(Intent(this@MainActivity, VoiceActivity::class.java).putExtra("lang", Layouts.tags[lang] ?: "en-US"))
            }
            override fun onTranslate() {
                val txt = input.text.toString()
                if (txt.isBlank()) { Toast.makeText(this@MainActivity, "Type something to translate", Toast.LENGTH_SHORT).show(); return }
                val src = prefs(this@MainActivity).getString("lang", "EN") ?: "EN"
                preview.setBusy(true)
                Tr.run(src, Tr.target(this@MainActivity, src), txt, { out ->
                    preview.setBusy(false); input.setText(out); input.setSelection(out.length)
                }, {
                    preview.setBusy(false)
                    Toast.makeText(this@MainActivity, "Translation failed. Internet is needed once to download the language pack.", Toast.LENGTH_LONG).show()
                })
            }
        })
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { addView(body); isFillViewport = false }, LinearLayout.LayoutParams(MATCH, 0, 1f))
        root.addView(input, LinearLayout.LayoutParams(MATCH, WRAP))
        root.addView(preview, LinearLayout.LayoutParams(MATCH, WRAP))
        setContentView(root)
        render()
    }

    override fun onResume() {
        super.onResume()
        if (::body.isInitialized) render()
    }

    // ---------- helpers ----------

    private fun alphaOf(c: Int, a: Float) = Color.argb((a * 255).toInt(), Color.red(c), Color.green(c), Color.blue(c))

    private fun rounded(color: Int, r: Int, stroke: Int = 0, strokeColor: Int = 0) = GradientDrawable().apply {
        cornerRadius = dp(r).toFloat(); setColor(color)
        if (stroke > 0) setStroke(dp(stroke), strokeColor)
    }

    private fun View.pressable() {
        setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.95f).scaleY(0.95f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(OvershootInterpolator(3f)).start()
            }
            false
        }
    }

    private fun bounce(v: View) {
        v.scaleX = 0.78f; v.scaleY = 0.78f
        v.animate().scaleX(1f).scaleY(1f).setDuration(460).setInterpolator(OvershootInterpolator(3.5f)).start()
    }

    private fun maybeBounce(v: View, key: String) {
        if (bounceKey == key) { bounceKey = null; v.post { bounce(v) } }
    }

    private fun tv(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }

    private fun column(vararg views: View) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        views.forEach { addView(it) }
    }

    private fun card(title: String, icon: Int, tint: Int, vararg views: View): LinearLayout {
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            addView(Chip(context, icon, tint), LinearLayout.LayoutParams(dp(40), dp(40)))
            addView(tv(title, 17f, ink, true), LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = dp(12) })
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(18))
            background = rounded(Color.WHITE, 28)
            elevation = dp(2).toFloat()
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(dp(16), dp(14), dp(16), 0) }
            addView(head)
            views.forEach { addView(it, lp(12)) }
        }
    }

    private fun switchTint(tint: Int) = Pair(
        ColorStateList(arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()), intArrayOf(tint, Color.parseColor("#9E9AA7"))),
        ColorStateList(arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()), intArrayOf(alphaOf(tint, 0.4f), Color.parseColor("#DDD9E2")))
    )

    private fun toggleRow(icon: Int, tint: Int, title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit): View {
        val chip = Chip(this, icon, tint)
        val sw = Switch(this).apply {
            isChecked = checked
            val (th, tr) = switchTint(tint)
            thumbTintList = th; trackTintList = tr
            setOnCheckedChangeListener { _, b -> chip.icon.play(); onChange(b) }
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            addView(chip, LinearLayout.LayoutParams(dp(40), dp(40)))
            addView(column(tv(title, 15f, ink, true), tv(sub, 12f, subC)),
                LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(12) })
            addView(sw)
        }
    }

    private fun stepRow(icon: Int, tint: Int, title: String, sub: String, done: Boolean, click: () -> Unit): View {
        val chip = Chip(this, icon, tint)
        val trailing: View = if (done) FrameLayout(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(green) }
            addView(IconView(context, Ic.CHECK, Color.WHITE), FrameLayout.LayoutParams(dp(16), dp(16), Gravity.CENTER))
        } else tv("Open", 13f, tint, true)
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(10), dp(14), dp(10))
            background = rounded(alphaOf(tint, 0.08f), 20)
            addView(chip, LinearLayout.LayoutParams(dp(40), dp(40)))
            addView(column(tv(title, 15f, ink, true), tv(sub, 12f, subC)),
                LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(12) })
            addView(trailing, if (done) LinearLayout.LayoutParams(dp(26), dp(26)) else LinearLayout.LayoutParams(WRAP, WRAP))
            pressable()
            setOnClickListener { chip.icon.play(); click() }
        }
    }

    private fun pill(t: String, bg: Int, fg: Int, icon: Int = -1, click: () -> Unit): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = rounded(bg, 24)
        }
        var iv: IconView? = null
        if (icon >= 0) {
            iv = IconView(this, icon, fg)
            row.addView(iv, LinearLayout.LayoutParams(dp(20), dp(20)).apply { rightMargin = dp(8) })
        }
        row.addView(tv(t, 14f, fg, true))
        row.pressable()
        row.setOnClickListener { iv?.play(); click() }
        return row
    }

    private fun optionChip(t: String, selected: Boolean, tint: Int, key: String, click: () -> Unit): View =
        tv(t, 14f, if (selected) Color.WHITE else ink, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(10), dp(16), dp(10))
            background = rounded(if (selected) tint else alphaOf(tint, 0.1f), 20)
            pressable()
            setOnClickListener { bounceKey = key; click() }
            maybeBounce(this, key)
        }

    private fun seek(f: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) { f(v) }
        override fun onStartTrackingTouch(s: SeekBar?) {}
        override fun onStopTrackingTouch(s: SeekBar?) {}
    }

    private fun tintSeek(sb: SeekBar, tint: Int) {
        sb.progressTintList = ColorStateList.valueOf(tint)
        sb.thumbTintList = ColorStateList.valueOf(tint)
    }

    private fun slider(label: String, key: String, def: Int, maxV: Int): View {
        val p = prefs(this)
        val cur = p.getInt(key, def)
        val tvl = tv("$label · $cur dp", 14f, ink)
        val sb = SeekBar(this).apply { max = maxV; progress = cur }
        tintSeek(sb, teal)
        sb.setOnSeekBarChangeListener(seek { v ->
            tvl.text = "$label · $v dp"
            p.edit().putInt(key, v).apply()
            preview.reload()
        })
        return column(tvl, sb)
    }

    private fun dot(color: Int, sel: Boolean, click: () -> Unit): View = View(this).apply {
        background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
            if (sel) setStroke(dp(3), ink) else setStroke(dp(1), Color.parseColor("#33000000"))
        }
        layoutParams = LinearLayout.LayoutParams(dp(36), dp(36)).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }
        pressable()
        setOnClickListener { click() }
    }

    private fun saveSeed(c: Int) {
        prefs(this).edit().putBoolean("custom", true).putInt("seed", c).apply()
    }

    // ---------- screen ----------

    private fun header(): View {
        val p = prefs(this)
        val idx = p.getInt("mascot", 1).let { if (it <= 0) 1 else it }
        val title = tv("Vibe Keyboard", 30f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            setOnClickListener {
                animate().scaleX(1.08f).scaleY(1.08f).setDuration(90).withEndAction {
                    animate().scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(OvershootInterpolator(3f)).start()
                }.start()
                if (++taps >= 7) { taps = 0; showEgg() }
            }
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(44), dp(20), dp(26))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.parseColor("#4A3A8C"), Color.parseColor("#7B5FD1"), Color.parseColor("#C0508E"))).apply {
                cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, dp(36).toFloat(), dp(36).toFloat(), dp(36).toFloat(), dp(36).toFloat())
            }
            addView(MascotView(context, idx, Color.parseColor("#FFE082"), 5.5f, true), LinearLayout.LayoutParams(dp(110), dp(90)))
            addView(title, lp(4))
            addView(tv("v3 · autocorrect · voice · translate", 13f, Color.parseColor("#E8DEF8")).apply { gravity = Gravity.CENTER }, lp(2))
        }
    }

    private fun render() {
        body.removeAllViews()
        val p = prefs(this)
        val cards = ArrayList<View>()
        body.addView(header())

        // Setup
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        val enabled = imm.enabledInputMethodList.any { it.packageName == packageName }
        val current = Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD) ?: ""
        val active = current.startsWith(packageName)
        cards.add(card("Setup", Ic.KEYS, purple,
            stepRow(Ic.KEYS, purple, "1 · Enable keyboard", if (enabled) "Enabled" else "Turn on Vibe Keyboard", enabled) {
                startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
            },
            stepRow(Ic.GLOBE, indigo, "2 · Choose keyboard", if (active) "Vibe Keyboard is active" else "Switch your input method", active) {
                imm.showInputMethodPicker()
            }))

        // Typing
        val tl = p.getString("tlang", "auto") ?: "auto"
        val langRow = LinearLayout(this)
        listOf("auto", "EN", "ES", "RU").forEach { v ->
            langRow.addView(optionChip(if (v == "auto") "Auto" else v, tl == v, green, "t$v") {
                p.edit().putString("tlang", v).apply(); render()
            }, LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = dp(8) })
        }
        val learned = AutoCorrect.learnedCount(this)
        cards.add(card("Typing", Ic.WAND, indigo,
            toggleRow(Ic.WAND, indigo, "Autocorrect", "Offline · English, Español, Русский", p.getBoolean("autocorrect", true)) {
                p.edit().putBoolean("autocorrect", it).apply(); preview.reload()
            },
            toggleRow(Ic.VIBRATE, teal, "Haptic feedback", "A tiny tap on every key", p.getBoolean("haptic", true)) {
                p.edit().putBoolean("haptic", it).apply(); preview.reload()
            },
            column(tv("Translate button → target language", 14f, ink, true), HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false; addView(langRow)
            }.also { (it.layoutParams ?: LinearLayout.LayoutParams(MATCH, WRAP)) }),
            pill("Forget $learned learned words", alphaOf(indigo, 0.12f), indigo, Ic.CHECK) {
                AutoCorrect.clearLearned(this); Toast.makeText(this, "Learned words cleared", Toast.LENGTH_SHORT).show(); render()
            }))

        // Theme
        val custom = p.getBoolean("custom", false)
        val sel = p.getInt("theme", 0)
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        Themes.presets.chunked(4).forEachIndexed { rowI, chunk ->
            val r = LinearLayout(this)
            chunk.forEachIndexed { j, th ->
                val i = rowI * 4 + j
                val sw = Swatch(this, th, !custom && i == sel).apply {
                    pressable()
                    setOnClickListener {
                        p.edit().putBoolean("custom", false).putInt("theme", i).apply()
                        bounceKey = "th$i"; preview.reload(); render()
                    }
                }
                maybeBounce(sw, "th$i")
                val cell = column(sw.also { }, tv(th.name, 11f, subC).apply { gravity = Gravity.CENTER })
                (cell.getChildAt(0)).layoutParams = LinearLayout.LayoutParams(MATCH, dp(64))
                r.addView(cell, LinearLayout.LayoutParams(0, WRAP, 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) })
            }
            grid.addView(r)
        }
        cards.add(card("Theme", Ic.PALETTE, pink, grid,
            toggleRow(Ic.SNOW, blue, "Falling snow", "Snowflakes drift across the keys", Themes.snowOn(this, Themes.current(this))) {
                p.edit().putInt("snow", if (it) 1 else 0).apply(); preview.reload()
            }))

        // Custom color
        val seed = p.getInt("seed", purple)
        val hsv = FloatArray(3)
        Color.colorToHSV(seed, hsv)
        val hex = EditText(this).apply {
            setText(String.format("#%06X", 0xFFFFFF and seed))
            setSingleLine(); setTextColor(ink)
        }
        hexField = hex
        val applyHex = pill("Apply HEX", alphaOf(pink, 0.12f), pink, Ic.PALETTE) {
            try {
                var s = hex.text.toString().trim()
                if (!s.startsWith("#")) s = "#$s"
                saveSeed(Color.parseColor(s))
                preview.reload(); render()
            } catch (e: Exception) {
                Toast.makeText(this, "Invalid HEX color", Toast.LENGTH_SHORT).show()
            }
        }
        val hue = SeekBar(this).apply { max = 359; progress = hsv[0].toInt().coerceIn(0, 359) }
        tintSeek(hue, pink)
        hue.setOnSeekBarChangeListener(seek { v ->
            val c = Color.HSVToColor(floatArrayOf(v.toFloat(), 0.8f, 0.85f))
            saveSeed(c)
            hexField?.setText(String.format("#%06X", 0xFFFFFF and c))
            preview.reload()
        })
        val dark = toggleRow(Ic.PALETTE, purple, "Dark keyboard", "Used by the custom color", p.getBoolean("dark", true)) {
            p.edit().putBoolean("dark", it).apply(); preview.reload()
        }
        val dots = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        palette.chunked(6).forEach { rowColors ->
            val r = LinearLayout(this)
            rowColors.forEach { hx ->
                val c = Color.parseColor(hx)
                r.addView(dot(c, custom && c == seed) { saveSeed(c); preview.reload(); render() })
            }
            dots.addView(r)
        }
        cards.add(card("Custom color", Ic.PALETTE, purple, dots, hue, hex, applyHex, dark))

        // Keys
        cards.add(card("Keys", Ic.KEYS, teal,
            slider("Key rounding", "radius", 12, 24),
            slider("Key spacing", "gap", 6, 12),
            slider("Row spacing", "rowgap", 6, 14)))

        // Pets
        val cur = p.getInt("mascot", 1)
        val petRow = LinearLayout(this)
        for (i in 0 until Mascots.art.size) {
            val tile = FrameLayout(this).apply {
                background = rounded(if (cur == i) alphaOf(orange, 0.18f) else alphaOf(orange, 0.06f), 20, if (cur == i) 2 else 0, orange)
                if (i == 0) addView(tv("Off", 14f, orange, true).apply { gravity = Gravity.CENTER }, FrameLayout.LayoutParams(MATCH, MATCH))
                else addView(MascotView(context, i, orange, 3.4f, true), FrameLayout.LayoutParams(MATCH, MATCH))
                if (i != 0) addView(tv(Mascots.names[i], 10f, subC).apply { gravity = Gravity.CENTER },
                    FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM).apply { bottomMargin = dp(4) })
                pressable()
                setOnClickListener {
                    p.edit().putInt("mascot", i).apply()
                    bounceKey = "m$i"; preview.reload(); render()
                }
            }
            maybeBounce(tile, "m$i")
            petRow.addView(tile, LinearLayout.LayoutParams(dp(88), dp(88)).apply { rightMargin = dp(10) })
        }
        cards.add(card("Pets", Ic.PAW, orange,
            tv("They float around the keyboard and follow your taps.", 13f, subC),
            HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(petRow) }))

        cards.forEachIndexed { i, c ->
            body.addView(c)
            if (firstRender) {
                c.alpha = 0f; c.translationY = dp(30).toFloat()
                c.animate().alpha(1f).translationY(0f).setStartDelay(80L * i + 120)
                    .setDuration(420).setInterpolator(DecelerateInterpolator()).start()
            }
        }
        body.addView(View(this), LinearLayout.LayoutParams(MATCH, dp(20)))
        firstRender = false
    }

    private fun showEgg() {
        val img = ImageView(this).apply {
            setImageResource(R.drawable.easter)
            scaleType = ImageView.ScaleType.CENTER_CROP
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) { o.setOval(0, 0, v.width, v.height) }
            }
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(dp(24), dp(24), dp(24), dp(8))
            addView(img, LinearLayout.LayoutParams(dp(220), dp(220)))
            addView(tv("made with vibes", 14f, subC).apply { gravity = Gravity.CENTER }, lp(12))
        }
        AlertDialog.Builder(this).setTitle("You found it!").setView(col).setPositiveButton("Nice", null).show()
        img.scaleX = 0f; img.scaleY = 0f; img.rotation = -90f
        img.animate().scaleX(1f).scaleY(1f).rotation(0f).setDuration(600).setInterpolator(OvershootInterpolator(2f)).start()
    }
}
